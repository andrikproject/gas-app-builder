package com.bankaltimtara.satpam.services;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.Schedule;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Helper class for managing push notifications using Firebase Cloud Messaging (FCM)
 * and local scheduled alarms for shift reminders.
 */
public class NotificationHelper {

    private static final String TAG = "NotificationHelper";

    // Notification channel IDs
    public static final String CHANNEL_SHIFT_REMINDER = "shift_reminder";
    public static final String CHANNEL_SCHEDULE_CHANGE = "schedule_change";
    public static final String CHANNEL_OVERTIME = "overtime";
    public static final String CHANNEL_GENERAL = "general";

    // Notification channel display names
    private static final String CHANNEL_SHIFT_REMINDER_NAME = "Shift Reminder";
    private static final String CHANNEL_SCHEDULE_CHANGE_NAME = "Schedule Change";
    private static final String CHANNEL_OVERTIME_NAME = "Overtime";
    private static final String CHANNEL_GENERAL_NAME = "General";

    // Notification channel descriptions
    private static final String CHANNEL_SHIFT_REMINDER_DESC = "Daily shift alerts and reminders";
    private static final String CHANNEL_SCHEDULE_CHANGE_DESC = "Schedule change notifications";
    private static final String CHANNEL_OVERTIME_DESC = "Overtime approval notifications";
    private static final String CHANNEL_GENERAL_DESC = "Other general notifications";

    // Intent action constants for alarm broadcast
    private static final String ACTION_SHIFT_REMINDER = "com.bankaltimtara.satpam.ACTION_SHIFT_REMINDER";
    public static final String EXTRA_SHIFT_ID = "shift_id";
    public static final String EXTRA_USER_ID = "user_id";
    public static final String EXTRA_TANGGAL = "tanggal";
    public static final String EXTRA_SHIFT_NAME = "shift_name";
    public static final String EXTRA_SHIFT_TIME = "shift_time";

    private static final int DEFAULT_NOTIFICATION_ICON = android.R.drawable.ic_dialog_info;

    private final Context context;
    private final NotificationManager notificationManager;

    public NotificationHelper(Context context) {
        this.context = context.getApplicationContext();
        this.notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannels();
    }

    // ──────────────────────────────────────────────
    // 1. Notification Channel Creation (Android 8+)
    // ──────────────────────────────────────────────

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return; // Channels not needed before Android 8
        }

        createChannel(
                CHANNEL_SHIFT_REMINDER,
                CHANNEL_SHIFT_REMINDER_NAME,
                CHANNEL_SHIFT_REMINDER_DESC,
                NotificationManager.IMPORTANCE_HIGH
        );
        createChannel(
                CHANNEL_SCHEDULE_CHANGE,
                CHANNEL_SCHEDULE_CHANGE_NAME,
                CHANNEL_SCHEDULE_CHANGE_DESC,
                NotificationManager.IMPORTANCE_DEFAULT
        );
        createChannel(
                CHANNEL_OVERTIME,
                CHANNEL_OVERTIME_NAME,
                CHANNEL_OVERTIME_DESC,
                NotificationManager.IMPORTANCE_DEFAULT
        );
        createChannel(
                CHANNEL_GENERAL,
                CHANNEL_GENERAL_NAME,
                CHANNEL_GENERAL_DESC,
                NotificationManager.IMPORTANCE_LOW
        );

        Log.d(TAG, "All notification channels created");
    }

    private void createChannel(String channelId, String name, String description, int importance) {
        NotificationChannel channel = new NotificationChannel(channelId, name, importance);
        channel.setDescription(description);
        // Use default sound from ringtone manager
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        channel.setSound(defaultSoundUri, null);
        channel.enableVibration(true);
        channel.setShowBadge(true);
        notificationManager.createNotificationChannel(channel);
    }

    // ──────────────────────────────────────────────
    // 2. Core notification display method
    // ──────────────────────────────────────────────

    /**
     * Displays a notification with the given parameters.
     *
     * @param channelId The notification channel ID
     * @param title     Notification title
     * @param message   Notification body text
     * @param intent    Optional PendingIntent to launch when notification is tapped;
     *                  if null, a default intent to open the app will be used
     */
    public void showNotification(String channelId, String title, String message, PendingIntent intent) {
        if (intent == null) {
            intent = getDefaultPendingIntent();
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(getNotificationIcon())
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(intent)
                .setPriority(getPriorityForChannel(channelId))
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        // Set sound per channel (already configured on channel for O+, but explicit for older)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            builder.setSound(defaultSoundUri);
        }

        int notificationId = generateNotificationId();
        notificationManager.notify(notificationId, builder.build());
        Log.d(TAG, "Notification shown: id=" + notificationId + ", title=" + title);
    }

    // ──────────────────────────────────────────────
    // 3. Convenience notification methods
    // ──────────────────────────────────────────────

    /**
     * Shows a shift reminder notification.
     */
    public void showShiftReminder(String userName, String shiftName, String time) {
        String title = "Shift Reminder";
        String message = String.format(
                "Halo %s, shift %s Anda dimulai pukul %s. Jangan lupa check-in tepat waktu!",
                userName, shiftName, time
        );
        showNotification(CHANNEL_SHIFT_REMINDER, title, message, null);
    }

    /**
     * Shows a schedule change notification.
     */
    public void showScheduleChange(String userName, String oldShift, String newShift, String date) {
        String title = "Schedule Change";
        String message;
        if (oldShift != null && !oldShift.isEmpty()) {
            message = String.format(
                    "Perubahan jadwal untuk %s pada %s: dari %s menjadi %s",
                    userName, date, oldShift, newShift
            );
        } else {
            message = String.format(
                    "Jadwal baru untuk %s pada %s: %s",
                    userName, date, newShift
            );
        }
        showNotification(CHANNEL_SCHEDULE_CHANGE, title, message, null);
    }

    /**
     * Shows an overtime status notification.
     */
    public void showOvertimeStatus(String userName, String status, double hours) {
        String title;
        String message;

        switch (status.toLowerCase()) {
            case "approved":
                title = "Overtime Approved";
                message = String.format(
                        "Pengajuan lembur %s selama %.1f jam telah disetujui.",
                        userName, hours
                );
                break;
            case "rejected":
                title = "Overtime Rejected";
                message = String.format(
                        "Pengajuan lembur %s selama %.1f jam telah ditolak.",
                        userName, hours
                );
                break;
            case "pending":
            default:
                title = "Overtime Request";
                message = String.format(
                        "%s mengajukan lembur selama %.1f jam. Silakan review.",
                        userName, hours
                );
                break;
        }

        showNotification(CHANNEL_OVERTIME, title, message, null);
    }

    // ──────────────────────────────────────────────
    // 4. Alarm scheduling for shift reminders
    // ──────────────────────────────────────────────

    /**
     * Schedules a daily repeating alarm for shift reminder.
     *
     * @param context  Application context
     * @param userId   User ID
     * @param tanggal  Date string (format: yyyy-MM-dd)
     * @param jamShift Shift start time (format: HH:mm)
     * @param shiftId  Shift ID for cancellation
     */
    public void scheduleShiftAlarm(Context context, String userId, String tanggal,
                                   String jamShift, String shiftId) {
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            Log.e(TAG, "AlarmManager is null, cannot schedule alarm");
            return;
        }

        Intent intent = new Intent(context, ShiftReminderReceiver.class);
        intent.setAction(ACTION_SHIFT_REMINDER);
        intent.putExtra(EXTRA_SHIFT_ID, shiftId);
        intent.putExtra(EXTRA_USER_ID, userId);
        intent.putExtra(EXTRA_TANGGAL, tanggal);
        intent.putExtra(EXTRA_SHIFT_TIME, jamShift);

        // Use unique request code based on shiftId hash to allow per-shift alarms
        int requestCode = shiftId.hashCode();

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Parse jamShift to set alarm time (remind 30 minutes before shift starts)
        Calendar alarmCalendar = parseTimeToCalendar(jamShift, tanggal);
        if (alarmCalendar == null) {
            Log.e(TAG, "Failed to parse shift time: " + jamShift);
            return;
        }

        // Remind 30 minutes before shift start
        alarmCalendar.add(Calendar.MINUTE, -30);

        long alarmTimeMillis = alarmCalendar.getTimeInMillis();
        long now = System.currentTimeMillis();

        // If the alarm time is in the past, schedule for the next day
        if (alarmTimeMillis <= now) {
            alarmCalendar.add(Calendar.DAY_OF_YEAR, 1);
            alarmTimeMillis = alarmCalendar.getTimeInMillis();
        }

        // Schedule repeating daily alarm
        alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                alarmTimeMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
        );

        Log.d(TAG, "Shift alarm scheduled for shiftId=" + shiftId
                + " at " + alarmCalendar.getTime().toString());
    }

    /**
     * Cancels a previously scheduled shift alarm.
     *
     * @param context Application context
     * @param shiftId Shift ID whose alarm to cancel
     */
    public void cancelAlarm(Context context, String shiftId) {
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            Log.e(TAG, "AlarmManager is null, cannot cancel alarm");
            return;
        }

        Intent intent = new Intent(context, ShiftReminderReceiver.class);
        intent.setAction(ACTION_SHIFT_REMINDER);

        int requestCode = shiftId.hashCode();
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel();

        Log.d(TAG, "Shift alarm cancelled for shiftId=" + shiftId);
    }

    /**
     * Bulk schedules alarms for all provided schedules.
     *
     * @param context    Application context
     * @param schedules  List of Schedule objects to schedule alarms for
     */
    public void scheduleAllShifts(Context context, List<Schedule> schedules) {
        if (schedules == null || schedules.isEmpty()) {
            Log.d(TAG, "No schedules to alarm");
            return;
        }

        for (Schedule schedule : schedules) {
            if (schedule.shiftId == null || schedule.tanggal == null) {
                continue; // Skip invalid schedules
            }

            // Extract shift name from schedule or derive from shiftId
            String shiftName = schedule.shiftNama != null ? schedule.shiftNama : schedule.shiftId;
            // Use schedule shift name as the "jamShift" — in practice you'd look up from Shift model
            // For now, schedule the alarm; the actual time is retrieved in the receiver
            scheduleShiftAlarm(
                    context,
                    schedule.userId,
                    schedule.tanggal,
                    shiftName,
                    schedule.shiftId
            );
        }

        Log.d(TAG, "Scheduled " + schedules.size() + " shift alarms");
    }

    // ──────────────────────────────────────────────
    // 5. Helper / Utility methods
    // ──────────────────────────────────────────────

    /**
     * Generates a unique notification ID based on the current timestamp.
     */
    private int generateNotificationId() {
        return (int) (System.currentTimeMillis() & 0x7FFFFFFF);
    }

    /**
     * Creates a default PendingIntent that opens the app's main activity.
     * Uses a reflection-safe approach to find the main activity if the class
     * is not directly available at compile time.
     */
    private PendingIntent getDefaultPendingIntent() {
        Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(context.getPackageName());

        if (intent == null) {
            // Fallback: just open the app launcher
            intent = context.getPackageManager()
                    .getLaunchIntentForPackage("com.bankaltimtara.satpam");
        }

        if (intent == null) {
            Log.w(TAG, "Could not find launch intent, using empty intent");
            return null;
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        return PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    /**
     * Returns the appropriate priority for a given channel ID.
     * Used for pre-Oreo devices.
     */
    private int getPriorityForChannel(String channelId) {
        switch (channelId) {
            case CHANNEL_SHIFT_REMINDER:
                return NotificationCompat.PRIORITY_HIGH;
            case CHANNEL_SCHEDULE_CHANGE:
            case CHANNEL_OVERTIME:
                return NotificationCompat.PRIORITY_DEFAULT;
            case CHANNEL_GENERAL:
            default:
                return NotificationCompat.PRIORITY_LOW;
        }
    }

    /**
     * Returns the notification icon resource ID.
     * Falls back to a default system icon if the custom one is not available.
     */
    private int getNotificationIcon() {
        // Try to use the app's custom notification icon first
        try {
            return R.drawable.ic_notification;
        } catch (Exception e) {
            // Fallback to system default icon
            return DEFAULT_NOTIFICATION_ICON;
        }
    }

    /**
     * Parses a time string and date string into a Calendar object.
     *
     * @param jamShift Time in HH:mm format
     * @param tanggal  Date in yyyy-MM-dd format
     * @return Calendar object, or null if parsing fails
     */
    private Calendar parseTimeToCalendar(String jamShift, String tanggal) {
        try {
            SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            String dateTimeStr = tanggal + " " + jamShift;
            Date date = dateTimeFormat.parse(dateTimeStr);
            if (date == null) return null;
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            return calendar;
        } catch (Exception e) {
            Log.e(TAG, "Error parsing time: " + jamShift + " on " + tanggal, e);
            return null;
        }
    }

    /**
     * Returns the NotificationManager instance used by this helper.
     */
    public NotificationManager getNotificationManager() {
        return notificationManager;
    }
}
