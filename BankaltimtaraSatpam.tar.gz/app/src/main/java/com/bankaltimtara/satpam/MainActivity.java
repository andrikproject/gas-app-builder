package com.bankaltimtara.satpam;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.appbar.CollapsingToolbarLayout;

public class MainActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private TextView tvSelamatDatang, tvNamaUser, tvRoleUser;
    private CardView cardDashboard, cardJadwal, cardAbsensi, cardLaporan, cardProfil;

    private PreferencesManager preferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        CollapsingToolbarLayout collapsingToolbar = findViewById(R.id.collapsingToolbar);
        collapsingToolbar.setTitle("Bankaltimtara Satpam");

        tvSelamatDatang = findViewById(R.id.tvSelamatDatang);
        tvNamaUser = findViewById(R.id.tvNamaUser);
        tvRoleUser = findViewById(R.id.tvRoleUser);

        cardDashboard = findViewById(R.id.cardDashboard);
        cardJadwal = findViewById(R.id.cardJadwal);
        cardAbsensi = findViewById(R.id.cardAbsensi);
        cardLaporan = findViewById(R.id.cardLaporan);
        cardProfil = findViewById(R.id.cardProfil);

        preferencesManager = PreferencesManager.getInstance(this);

        if (!preferencesManager.isLoggedIn()) {
            logout();
            return;
        }

        setupUserInfo();
        setupClickListeners();
    }

    private void setupUserInfo() {
        String nama = preferencesManager.getUserName();
        String role = preferencesManager.getUserRole();

        tvSelamatDatang.setText("Selamat Datang");
        tvNamaUser.setText(nama != null && !nama.isEmpty() ? nama : "Satpam");
        tvRoleUser.setText(role != null && role.equalsIgnoreCase("admin") ? "Admin" : "Satpam");
    }

    private void setupClickListeners() {
        cardDashboard.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, DashboardActivity.class)));
        cardJadwal.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ScheduleActivity.class)));
        cardAbsensi.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AttendanceActivity.class)));
        cardLaporan.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReportActivity.class)));
        cardProfil.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ProfileActivity.class)));
    }

    private void logout() {
        preferencesManager.logout();
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
