package com.bankaltimtara.satpam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.bankaltimtara.satpam.models.Attendance;
import com.bankaltimtara.satpam.models.Schedule;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.DateUtils;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private TextView tvStatusHariIni, tvShiftHariIni, tvJamMasuk, tvJamKeluar;
    private TextView tvTotalHadir, tvTotalTerlambat, tvTotalAlpa;
    private CardView cardJadwal, cardAbsensi;

    private FirebaseService firebaseService;
    private PreferencesManager preferencesManager;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Dashboard");
        }

        progressBar = findViewById(R.id.progressBar);
        tvStatusHariIni = findViewById(R.id.tvStatusHariIni);
        tvShiftHariIni = findViewById(R.id.tvShiftHariIni);
        tvJamMasuk = findViewById(R.id.tvJamMasuk);
        tvJamKeluar = findViewById(R.id.tvJamKeluar);
        tvTotalHadir = findViewById(R.id.tvTotalHadir);
        tvTotalTerlambat = findViewById(R.id.tvTotalTerlambat);
        tvTotalAlpa = findViewById(R.id.tvTotalAlpa);
        cardJadwal = findViewById(R.id.cardJadwal);
        cardAbsensi = findViewById(R.id.cardAbsensi);

        firebaseService = FirebaseService.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        userId = preferencesManager.getUserId();

        cardJadwal.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, ScheduleActivity.class)));
        cardAbsensi.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, AttendanceActivity.class)));

        loadData();
    }

    private void loadData() {
        showLoading(true);

        // Load jadwal hari ini
        String today = DateUtils.today();
        firebaseService.getSchedulesByUser(userId, new FirebaseService.FirebaseCallback<List<Schedule>>() {
            @Override
            public void onSuccess(List<Schedule> schedules) {
                Schedule todaySchedule = null;
                for (Schedule s : schedules) {
                    if (s.tanggal != null && s.tanggal.equals(today)) {
                        todaySchedule = s;
                        break;
                    }
                }

                Schedule finalSchedule = todaySchedule;
                runOnUiThread(() -> {
                    if (finalSchedule != null) {
                        tvShiftHariIni.setText(finalSchedule.shiftNama != null ? finalSchedule.shiftNama : "-");
                        tvJamMasuk.setText(finalSchedule.checkInTime != null ? finalSchedule.checkInTime : "-");
                        tvJamKeluar.setText(finalSchedule.checkOutTime != null ? finalSchedule.checkOutTime : "-");

                        String status = finalSchedule.status;
                        if (status == null) status = "terjadwal";
                        switch (status) {
                            case "checkin":
                                tvStatusHariIni.setText("Sudah Check In");
                                break;
                            case "checkout":
                                tvStatusHariIni.setText("Selesai");
                                break;
                            case "libur":
                                tvStatusHariIni.setText("Libur");
                                break;
                            default:
                                tvStatusHariIni.setText("Menunggu Check In");
                                break;
                        }
                    } else {
                        tvShiftHariIni.setText("Tidak ada jadwal");
                        tvJamMasuk.setText("-");
                        tvJamKeluar.setText("-");
                        tvStatusHariIni.setText("Libur");
                    }
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> Snackbar.make(coordinatorLayout,
                        "Gagal memuat jadwal: " + errorMessage, Snackbar.LENGTH_LONG).show());
            }
        });

        // Load statistik kehadiran
        firebaseService.getAttendanceByUser(userId, new FirebaseService.FirebaseCallback<List<Attendance>>() {
            @Override
            public void onSuccess(List<Attendance> attendanceList) {
                int hadir = 0, terlambat = 0, alpa = 0;
                String currentMonth = DateUtils.today().substring(0, 7);
                for (Attendance a : attendanceList) {
                    if (a.tanggal != null && a.tanggal.startsWith(currentMonth)) {
                        String s = a.status != null ? a.status : "";
                        switch (s) {
                            case "hadir": hadir++; break;
                            case "terlambat": terlambat++; break;
                            case "alpa": alpa++; break;
                        }
                    }
                }

                int finalHadir = hadir;
                int finalTerlambat = terlambat;
                int finalAlpa = alpa;
                runOnUiThread(() -> {
                    tvTotalHadir.setText(String.valueOf(finalHadir));
                    tvTotalTerlambat.setText(String.valueOf(finalTerlambat));
                    tvTotalAlpa.setText(String.valueOf(finalAlpa));
                    showLoading(false);
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat statistik: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
