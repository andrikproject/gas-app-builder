package com.bankaltimtara.satpam.admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.bankaltimtara.satpam.LoginActivity;
import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.Attendance;
import com.bankaltimtara.satpam.models.Schedule;
import com.bankaltimtara.satpam.models.User;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class AdminDashboardActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private TextView tvTotalSatpam, tvTotalJadwal, tvTotalHadir, tvTotalTerlambat;
    private CardView cardKelolaJadwal, cardKelolaShift, cardAbsensi, cardLaporan, cardUser, cardLogout;

    private FirebaseService firebaseService;
    private PreferencesManager preferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Admin Dashboard");
        }

        progressBar = findViewById(R.id.progressBar);
        tvTotalSatpam = findViewById(R.id.tvTotalSatpam);
        tvTotalJadwal = findViewById(R.id.tvTotalJadwal);
        tvTotalHadir = findViewById(R.id.tvTotalHadir);
        tvTotalTerlambat = findViewById(R.id.tvTotalTerlambat);
        cardKelolaJadwal = findViewById(R.id.cardKelolaJadwal);
        cardKelolaShift = findViewById(R.id.cardKelolaShift);
        cardAbsensi = findViewById(R.id.cardAbsensi);
        cardLaporan = findViewById(R.id.cardLaporan);
        cardUser = findViewById(R.id.cardUser);
        cardLogout = findViewById(R.id.cardLogout);

        firebaseService = FirebaseService.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);

        if (!preferencesManager.isLoggedIn()) {
            logout();
            return;
        }

        setupClickListeners();
        loadStats();
    }

    private void setupClickListeners() {
        cardKelolaJadwal.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, AdminScheduleActivity.class)));
        cardKelolaShift.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, AdminShiftConfigActivity.class)));
        cardAbsensi.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, AdminAttendanceActivity.class)));
        cardLaporan.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, AdminReportActivity.class)));
        cardUser.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, AdminUserManagementActivity.class)));
        cardLogout.setOnClickListener(v -> logout());
    }

    private void loadStats() {
        showLoading(true);

        // Total satpam
        firebaseService.getUsers(new FirebaseService.FirebaseCallback<List<User>>() {
            @Override
            public void onSuccess(List<User> users) {
                int total = 0;
                if (users != null) {
                    for (User u : users) {
                        if (u.role != null && u.role.equalsIgnoreCase("satpam") && u.aktif) {
                            total++;
                        }
                    }
                }
                int finalTotal = total;
                runOnUiThread(() -> tvTotalSatpam.setText(String.valueOf(finalTotal)));
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> tvTotalSatpam.setText("0"));
            }
        });

        // Total jadwal bulan ini
        firebaseService.getSchedules(new FirebaseService.FirebaseCallback<List<Schedule>>() {
            @Override
            public void onSuccess(List<Schedule> schedules) {
                int total = schedules != null ? schedules.size() : 0;
                runOnUiThread(() -> tvTotalJadwal.setText(String.valueOf(total)));
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> tvTotalJadwal.setText("0"));
            }
        });

        // Statistik absensi
        firebaseService.getAttendance(new FirebaseService.FirebaseCallback<List<Attendance>>() {
            @Override
            public void onSuccess(List<Attendance> attendanceList) {
                int hadir = 0, terlambat = 0;
                if (attendanceList != null) {
                    for (Attendance a : attendanceList) {
                        String s = a.status != null ? a.status : "";
                        if (s.equals("hadir")) hadir++;
                        else if (s.equals("terlambat")) terlambat++;
                    }
                }
                int finalHadir = hadir;
                int finalTerlambat = terlambat;
                runOnUiThread(() -> {
                    tvTotalHadir.setText(String.valueOf(finalHadir));
                    tvTotalTerlambat.setText(String.valueOf(finalTerlambat));
                    showLoading(false);
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat statistik: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void logout() {
        preferencesManager.logout();
        Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }
}
