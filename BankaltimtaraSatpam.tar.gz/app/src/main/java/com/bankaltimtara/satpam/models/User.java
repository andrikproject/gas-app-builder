package com.bankaltimtara.satpam.models;

import java.util.HashMap;
import java.util.Map;

public class User {
    public String id, name, email, phone, role, nip, posisi, fotoUrl;
    public boolean aktif;

    public User() {}

    public User(String id, String name, String email, String role) {
        this.id = id; this.name = name; this.email = email; this.role = role;
        this.aktif = true;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("name", name); m.put("email", email); m.put("phone", phone);
        m.put("role", role); m.put("nip", nip); m.put("posisi", posisi);
        m.put("fotoUrl", fotoUrl); m.put("aktif", aktif);
        return m;
    }

    public static User fromMap(String id, Map<String, Object> m) {
        User u = new User();
        u.id = id; u.name = (String) m.get("name"); u.email = (String) m.get("email");
        u.phone = (String) m.get("phone"); u.role = (String) m.get("role");
        u.nip = (String) m.get("nip"); u.posisi = (String) m.get("posisi");
        u.fotoUrl = (String) m.get("fotoUrl");
        u.aktif = m.containsKey("aktif") ? (Boolean) m.get("aktif") : true;
        return u;
    }
}
