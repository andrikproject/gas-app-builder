# Bankaltimtara Satpam ProGuard Rules
-keepattributes Signature
-keepattributes *Annotation*

# Firebase
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# Models
-keep class com.bankaltimtara.satpam.models.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Keep Gson/JSON
-keep class org.json.** { *; }
