package com.bankaltimtara.satpam.admin;

import android.os.Bundle;
import android.widget.*;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.*;
import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.Overtime;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.google.android.material.snackbar.Snackbar;
import java.util.*;

public class AdminOvertimeActivity extends AppCompatActivity {
    private RecyclerView rvOvertime;
    private OvertimeAdapter adapter;
    private List<Overtime> overtimeList = new ArrayList<>();
    private FirebaseService firebase;
    private TextView tvPending, tvApproved, tvRejected;
    private View root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_overtime);
        root = findViewById(android.R.id.content);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Approval Lembur");

        firebase = FirebaseService.getInstance(this);
        tvPending = findViewById(R.id.tvOvertimePending);
        tvApproved = findViewById(R.id.tvOvertimeApproved);
        tvRejected = findViewById(R.id.tvOvertimeRejected);

        rvOvertime = findViewById(R.id.rvOvertime);
        rvOvertime.setLayoutManager(new LinearLayoutManager(this));
        adapter = new OvertimeAdapter();
        rvOvertime.setAdapter(adapter);

        loadOvertime();
    }

    private void loadOvertime() {
        firebase.getOvertime(new FirebaseService.FirebaseCallback<List<Overtime>>() {
            @Override
            public void onSuccess(List<Overtime> data) {
                overtimeList = data;
                int pending = 0, approved = 0, rejected = 0;
                for (Overtime o : data) {
                    if (o.status.equals(Overtime.STATUS_PENDING)) pending++;
                    else if (o.status.equals(Overtime.STATUS_DISETUJUI)) approved++;
                    else if (o.status.equals(Overtime.STATUS_DITOLAK)) rejected++;
                }
                tvPending.setText(String.valueOf(pending));
                tvApproved.setText(String.valueOf(approved));
                tvRejected.setText(String.valueOf(rejected));
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String error) {
                Snackbar.make(root, "Error: " + error, Snackbar.LENGTH_LONG).show();
            }
        });
    }

    private void approveOvertime(Overtime o, boolean approved) {
        String status = approved ? Overtime.STATUS_DISETUJUI : Overtime.STATUS_DITOLAK;
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", status);
        updates.put("approvedAt", System.currentTimeMillis());

        firebase.updateOvertime(o.id, updates, new FirebaseService.FirebaseCallback<Void>() {
            @Override
            public void onSuccess(Void v) {
                Snackbar.make(root, approved ? "✅ Lembur disetujui" : "❌ Lembur ditolak", Snackbar.LENGTH_SHORT).show();
                loadOvertime();
            }

            @Override
            public void onError(String error) {
                Snackbar.make(root, "Error: " + error, Snackbar.LENGTH_LONG).show();
            }
        });
    }

    class OvertimeAdapter extends RecyclerView.Adapter<OvertimeAdapter.ViewHolder> {
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = getLayoutInflater().inflate(R.layout.item_overtime, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder h, int i) {
            Overtime o = overtimeList.get(i);
            h.tvName.setText(o.userName);
            h.tvDate.setText(o.tanggal + " - " + o.shift);
            h.tvHours.setText(o.durasiJam + " jam");
            h.tvAlasan.setText(o.alasan);
            h.tvPay.setText("Rp " + String.format("%,.0f", o.totalBayaran));

            String statusColor;
            switch (o.status) {
                case "disetujui": statusColor = "✅ Disetujui"; h.btnApprove.setVisibility(View.GONE); h.btnReject.setVisibility(View.GONE); break;
                case "ditolak": statusColor = "❌ Ditolak"; h.btnApprove.setVisibility(View.GONE); h.btnReject.setVisibility(View.GONE); break;
                default: statusColor = "⏳ Pending"; h.btnApprove.setVisibility(View.VISIBLE); h.btnReject.setVisibility(View.VISIBLE); break;
            }
            h.tvStatus.setText(statusColor);

            h.btnApprove.setOnClickListener(v -> approveOvertime(o, true));
            h.btnReject.setOnClickListener(v -> approveOvertime(o, false));
        }

        @Override
        public int getItemCount() { return overtimeList.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvDate, tvHours, tvAlasan, tvPay, tvStatus;
            Button btnApprove, btnReject;
            ViewHolder(View v) {
                super(v);
                tvName = v.findViewById(R.id.itemOvertimeName);
                tvDate = v.findViewById(R.id.itemOvertimeDate);
                tvHours = v.findViewById(R.id.itemOvertimeHours);
                tvAlasan = v.findViewById(R.id.itemOvertimeAlasan);
                tvPay = v.findViewById(R.id.itemOvertimePay);
                tvStatus = v.findViewById(R.id.itemOvertimeStatus);
                btnApprove = v.findViewById(R.id.btnOvertimeApprove);
                btnReject = v.findViewById(R.id.btnOvertimeReject);
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
