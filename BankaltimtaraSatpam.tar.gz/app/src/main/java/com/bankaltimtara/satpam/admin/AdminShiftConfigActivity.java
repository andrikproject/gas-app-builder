package com.bankaltimtara.satpam.admin;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.Shift;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class AdminShiftConfigActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView tvEmpty;

    private FirebaseService firebaseService;

    private List<Shift> shiftList;
    private ShiftAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_shift_config);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Konfigurasi Shift");
        }

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseService = FirebaseService.getInstance(this);

        shiftList = new ArrayList<>();
        adapter = new ShiftAdapter(shiftList, this::showEditShiftDialog, this::confirmDeleteShift);
        recyclerView.setAdapter(adapter);

        findViewById(R.id.fabTambahShift).setOnClickListener(v -> showAddShiftDialog());

        loadShifts();
    }

    private void loadShifts() {
        showLoading(true);

        firebaseService.getShifts(new FirebaseService.FirebaseCallback<List<Shift>>() {
            @Override
            public void onSuccess(List<Shift> shifts) {
                runOnUiThread(() -> {
                    showLoading(false);
                    shiftList.clear();
                    if (shifts != null) {
                        shiftList.addAll(shifts);
                    }
                    updateView();
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat shift: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showAddShiftDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_shift_form, null);
        EditText edtNama = view.findViewById(R.id.edtNamaShift);
        TextView tvJamMulai = view.findViewById(R.id.tvJamMulai);
        TextView tvJamSelesai = view.findViewById(R.id.tvJamSelesai);
        Spinner spinnerKategori = view.findViewById(R.id.spinnerKategori);

        ArrayAdapter<String> kategoriAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"8jam", "12jam"});
        spinnerKategori.setAdapter(kategoriAdapter);

        tvJamMulai.setOnClickListener(v -> {
            TimePickerDialog timePicker = new TimePickerDialog(this,
                    (view1, hourOfDay, minute) ->
                            tvJamMulai.setText(String.format("%02d:%02d", hourOfDay, minute)),
                    6, 0, true);
            timePicker.show();
        });

        tvJamSelesai.setOnClickListener(v -> {
            TimePickerDialog timePicker = new TimePickerDialog(this,
                    (view12, hourOfDay, minute) ->
                            tvJamSelesai.setText(String.format("%02d:%02d", hourOfDay, minute)),
                    14, 0, true);
            timePicker.show();
        });

        new MaterialAlertDialogBuilder(this)
                .setTitle("Tambah Shift Baru")
                .setView(view)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String nama = edtNama.getText().toString().trim();
                    String jamMulai = tvJamMulai.getText().toString();
                    String jamSelesai = tvJamSelesai.getText().toString();
                    String kategori = spinnerKategori.getSelectedItem().toString();

                    if (nama.isEmpty() || jamMulai.equals("Pilih") || jamSelesai.equals("Pilih")) {
                        Snackbar.make(coordinatorLayout,
                                "Semua field harus diisi", Snackbar.LENGTH_LONG).show();
                        return;
                    }

                    showLoading(true);
                    Shift shift = new Shift(null, nama, jamMulai, jamSelesai, kategori);
                    firebaseService.createShift(shift, new FirebaseService.FirebaseCallback<Shift>() {
                        @Override
                        public void onSuccess(Shift created) {
                            runOnUiThread(() -> {
                                showLoading(false);
                                Snackbar.make(coordinatorLayout,
                                        "Shift " + nama + " berhasil ditambahkan",
                                        Snackbar.LENGTH_LONG).show();
                                loadShifts();
                            });
                        }

                        @Override
                        public void onError(String errorMessage) {
                            runOnUiThread(() -> {
                                showLoading(false);
                                Snackbar.make(coordinatorLayout,
                                        "Gagal: " + errorMessage, Snackbar.LENGTH_LONG).show();
                            });
                        }
                    });
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showEditShiftDialog(Shift shift) {
        View view = getLayoutInflater().inflate(R.layout.dialog_shift_form, null);
        EditText edtNama = view.findViewById(R.id.edtNamaShift);
        TextView tvJamMulai = view.findViewById(R.id.tvJamMulai);
        TextView tvJamSelesai = view.findViewById(R.id.tvJamSelesai);
        Spinner spinnerKategori = view.findViewById(R.id.spinnerKategori);

        edtNama.setText(shift.nama);
        tvJamMulai.setText(shift.jamMulai);
        tvJamSelesai.setText(shift.jamSelesai);

        ArrayAdapter<String> kategoriAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"8jam", "12jam"});
        spinnerKategori.setAdapter(kategoriAdapter);
        if ("12jam".equals(shift.kategori)) {
            spinnerKategori.setSelection(1);
        }

        new MaterialAlertDialogBuilder(this)
                .setTitle("Edit Shift")
                .setView(view)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String nama = edtNama.getText().toString().trim();
                    // Note: Simple update via recreate - production would use updateDocument
                    Snackbar.make(coordinatorLayout,
                            "Edit shift akan tersedia di versi berikutnya",
                            Snackbar.LENGTH_LONG).show();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void confirmDeleteShift(Shift shift) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Hapus Shift")
                .setMessage("Apakah Anda yakin ingin menghapus shift " + shift.nama + "?")
                .setPositiveButton("Hapus", (dialog, which) -> {
                    Snackbar.make(coordinatorLayout,
                            "Fitur hapus shift akan tersedia di versi berikutnya",
                            Snackbar.LENGTH_LONG).show();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void updateView() {
        if (shiftList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
        }
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    static class ShiftAdapter extends RecyclerView.Adapter<ShiftAdapter.ViewHolder> {
        private final List<Shift> shifts;
        private final OnEditListener editListener;
        private final OnDeleteListener deleteListener;

        interface OnEditListener { void onEdit(Shift shift); }
        interface OnDeleteListener { void onDelete(Shift shift); }

        ShiftAdapter(List<Shift> shifts, OnEditListener edit, OnDeleteListener delete) {
            this.shifts = shifts;
            this.editListener = edit;
            this.deleteListener = delete;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_shift, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Shift s = shifts.get(position);
            holder.tvNama.setText(s.nama);
            holder.tvJam.setText(s.jamMulai + " - " + s.jamSelesai);
            holder.tvKategori.setText(s.kategori + " (" + s.durasiJam + " jam)");

            holder.btnEdit.setOnClickListener(v -> editListener.onEdit(s));
            holder.btnHapus.setOnClickListener(v -> deleteListener.onDelete(s));
        }

        @Override
        public int getItemCount() {
            return shifts.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvNama, tvJam, tvKategori;
            Button btnEdit, btnHapus;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvNama = itemView.findViewById(R.id.tvNamaShift);
                tvJam = itemView.findViewById(R.id.tvJamShift);
                tvKategori = itemView.findViewById(R.id.tvKategoriShift);
                btnEdit = itemView.findViewById(R.id.btnEditShift);
                btnHapus = itemView.findViewById(R.id.btnHapusShift);
            }
        }
    }
}
