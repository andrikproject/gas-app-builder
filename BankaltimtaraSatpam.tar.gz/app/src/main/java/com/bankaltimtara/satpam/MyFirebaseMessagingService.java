package com.bankaltimtara.satpam;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.bankaltimtara.satpam.services.NotificationHelper;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        Log.d("FCM", "New token: " + token);
        PreferencesManager.getInstance(this).setToken(token);
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);

        String title = message.getNotification() != null ? message.getNotification().getTitle() : "Bankaltimtara Satpam";
        String body = message.getNotification() != null ? message.getNotification().getBody() : "";
        String channel = message.getData().getOrDefault("channel", NotificationHelper.CHANNEL_GENERAL);
        String type = message.getData().getOrDefault("type", "general");

        // Log
        Log.d("FCM", "Message: " + title + " - " + body);

        // Show notification based on type
        NotificationHelper helper = new NotificationHelper(this);
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        switch (type) {
            case "shift_reminder":
                helper.showShiftReminder(
                    message.getData().getOrDefault("userName", "Petugas"),
                    message.getData().getOrDefault("shiftName", ""),
                    message.getData().getOrDefault("shiftTime", "")
                );
                break;
            case "schedule_change":
                helper.showScheduleChange(
                    message.getData().getOrDefault("userName", "Petugas"),
                    message.getData().getOrDefault("oldShift", ""),
                    message.getData().getOrDefault("newShift", ""),
                    message.getData().getOrDefault("tanggal", "")
                );
                break;
            case "overtime":
                helper.showOvertimeStatus(
                    message.getData().getOrDefault("userName", ""),
                    message.getData().getOrDefault("status", ""),
                    Double.parseDouble(message.getData().getOrDefault("hours", "0"))
                );
                break;
            default:
                helper.showNotification(channel, title, body, intent);
                break;
        }
    }
}
