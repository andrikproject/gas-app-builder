package com.bankaltimtara.satpam.services;

import android.content.Context;
import android.util.Log;

import com.bankaltimtara.satpam.models.Attendance;
import com.bankaltimtara.satpam.models.Overtime;
import com.bankaltimtara.satpam.models.Schedule;
import com.bankaltimtara.satpam.models.Shift;
import com.bankaltimtara.satpam.models.User;
import com.bankaltimtara.satpam.utils.Constants;
import com.bankaltimtara.satpam.utils.PreferencesManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Firebase REST client for Bankaltimtara Satpam.
 * Handles Firebase Auth, Cloud Firestore CRUD, and FCM messaging
 * using Firebase REST APIs with no SDK dependencies.
 */
public class FirebaseService {

    private static final String TAG = "FirebaseService";

    // Auth REST endpoints
    private static final String AUTH_BASE = "https://identitytoolkit.googleapis.com/v1";
    private static final String AUTH_LOGIN_ENDPOINT = AUTH_BASE + "/accounts:signInWithPassword?key=";
    private static final String AUTH_SIGNUP_ENDPOINT = AUTH_BASE + "/accounts:signUp?key=";
    private static final String AUTH_LOOKUP_ENDPOINT = AUTH_BASE + "/accounts:lookup?key=";

    // Firestore REST base
    private static final String FIRESTORE_BASE =
            "https://firestore.googleapis.com/v1/projects/"
                    + Constants.FIREBASE_PROJECT_ID
                    + "/databases/(default)/documents";

    private static final String FIRESTORE_RUN_QUERY =
            "https://firestore.googleapis.com/v1/projects/"
                    + Constants.FIREBASE_PROJECT_ID
                    + "/databases/(default)/documents:runQuery?key="
                    + Constants.FIREBASE_API_KEY;

    // FCM legacy endpoint
    private static final String FCM_URL = "https://fcm.googleapis.com/fcm/send";

    private static FirebaseService instance;
    private final Context context;

    // -----------------------------------------------------------------------
    // Callback interface
    // -----------------------------------------------------------------------

    public interface FirebaseCallback<T> {
        void onSuccess(T result);
        void onError(String errorMessage);
    }

    // -----------------------------------------------------------------------
    // Singleton
    // -----------------------------------------------------------------------

    private FirebaseService(Context context) {
        this.context = context.getApplicationContext();
    }

    public static synchronized FirebaseService getInstance(Context context) {
        if (instance == null) {
            instance = new FirebaseService(context);
        }
        return instance;
    }

    // =======================================================================
    // 1. FIREBASE AUTH
    // =======================================================================

    /**
     * Login with email & password via Firebase Auth REST API.
     * On success, saves user session to PreferencesManager and returns a User object.
     */
    public void login(final String email, final String password,
                      final FirebaseCallback<User> callback) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("password", password);
                body.put("returnSecureToken", true);

                String response = httpPost(AUTH_LOGIN_ENDPOINT + Constants.FIREBASE_API_KEY,
                        body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    String msg = json.getJSONObject("error").optString("message", "Login failed");
                    callback.onError(msg);
                    return;
                }

                final String idToken = json.getString("idToken");
                final String localId = json.getString("localId");
                final String email_ = json.optString("email", email);

                // Save basic session
                PreferencesManager prefs = PreferencesManager.getInstance(context);
                prefs.setUserId(localId);
                prefs.setLoggedIn(true);

                // Fetch user profile from Firestore
                getUserById(localId, new FirebaseCallback<User>() {
                    @Override
                    public void onSuccess(User user) {
                        if (user == null) {
                            // No profile yet — create minimal User from auth data
                            User u = new User(localId, "", email_, "satpam");
                            prefs.saveUser(u);
                            callback.onSuccess(u);
                        } else {
                            prefs.saveUser(user);
                            callback.onSuccess(user);
                        }
                    }

                    @Override
                    public void onError(String errorMessage) {
                        // Auth succeeded but profile fetch failed — return basic user
                        User u = new User(localId, "", email_, "satpam");
                        prefs.saveUser(u);
                        callback.onSuccess(u);
                    }
                });

            } catch (Exception e) {
                Log.e(TAG, "login error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Login failed");
            }
        }).start();
    }

    /**
     * Register new user via Firebase Auth REST API.
     * Also creates a user document in Firestore.
     */
    public void register(final String email, final String password, final String name,
                         final FirebaseCallback<User> callback) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("password", password);
                body.put("returnSecureToken", true);

                String response = httpPost(AUTH_SIGNUP_ENDPOINT + Constants.FIREBASE_API_KEY,
                        body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    String msg = json.getJSONObject("error").optString("message", "Registration failed");
                    callback.onError(msg);
                    return;
                }

                final String localId = json.getString("localId");

                // Create user document in Firestore
                final User newUser = new User(localId, name, email, "satpam");
                createUserDocument(newUser, new FirebaseCallback<User>() {
                    @Override
                    public void onSuccess(User user) {
                        PreferencesManager.getInstance(context).saveUser(user);
                        callback.onSuccess(user);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        // Registration succeeded but Firestore doc creation failed
                        PreferencesManager.getInstance(context).saveUser(newUser);
                        callback.onSuccess(newUser);
                    }
                });

            } catch (Exception e) {
                Log.e(TAG, "register error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Registration failed");
            }
        }).start();
    }

    // =======================================================================
    // 2. USERS CRUD
    // =======================================================================

    public void getUsers(final FirebaseCallback<List<User>> callback) {
        listCollection(Constants.COLLECTION_USERS, new FirebaseCallback<List<User>>() {
            @Override
            public void onSuccess(List<User> users) {
                callback.onSuccess(users);
            }

            @Override
            public void onError(String errorMessage) {
                callback.onError(errorMessage);
            }
        });
    }

    public void createUser(final User user, final FirebaseCallback<User> callback) {
        createUserDocument(user, callback);
    }

    /**
     * Fetch a single user by document ID.
     */
    public void getUserById(final String userId, final FirebaseCallback<User> callback) {
        new Thread(() -> {
            try {
                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_USERS
                        + "/" + userId + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpGet(url);
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    callback.onSuccess(null);
                    return;
                }

                User user = FirestoreDocument.parseUser(json);
                callback.onSuccess(user);
            } catch (Exception e) {
                Log.e(TAG, "getUserById error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to get user");
            }
        }).start();
    }

    // =======================================================================
    // 3. SHIFTS CRUD
    // =======================================================================

    public void getShifts(final FirebaseCallback<List<Shift>> callback) {
        new Thread(() -> {
            try {
                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_SHIFTS
                        + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpGet(url);
                List<Shift> shifts = FirestoreDocument.parseShifts(new JSONObject(response));
                callback.onSuccess(shifts);
            } catch (Exception e) {
                Log.e(TAG, "getShifts error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to get shifts");
            }
        }).start();
    }

    public void createShift(final Shift shift, final FirebaseCallback<Shift> callback) {
        new Thread(() -> {
            try {
                String docId = shift.id != null && !shift.id.isEmpty()
                        ? shift.id : UUID.randomUUID().toString();
                Map<String, Object> data = shift.toMap();
                JSONObject fields = FirestoreDocument.toFirestoreFields(data);

                JSONObject body = new JSONObject();
                body.put("fields", fields);

                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_SHIFTS
                        + "/" + docId + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpPatch(url, body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    String msg = json.getJSONObject("error").optString("message", "Create failed");
                    callback.onError(msg);
                    return;
                }

                String returnedId = extractDocId(json);
                Shift created = Shift.fromMap(returnedId, data);
                callback.onSuccess(created);
            } catch (Exception e) {
                Log.e(TAG, "createShift error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to create shift");
            }
        }).start();
    }

    // =======================================================================
    // 4. SCHEDULES CRUD
    // =======================================================================

    public void getSchedules(final FirebaseCallback<List<Schedule>> callback) {
        new Thread(() -> {
            try {
                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_SCHEDULES
                        + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpGet(url);
                List<Schedule> schedules = FirestoreDocument.parseSchedules(new JSONObject(response));
                callback.onSuccess(schedules);
            } catch (Exception e) {
                Log.e(TAG, "getSchedules error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to get schedules");
            }
        }).start();
    }

    /**
     * Get schedules filtered by userId using Firestore runQuery.
     */
    public void getSchedulesByUser(final String userId,
                                   final FirebaseCallback<List<Schedule>> callback) {
        queryWhere(Constants.COLLECTION_SCHEDULES, "userId", "EQUAL", userId,
                new FirebaseCallback<List<Map<String, Object>>>() {
                    @Override
                    public void onSuccess(List<Map<String, Object>> results) {
                        List<Schedule> schedules = new ArrayList<>();
                        for (Map<String, Object> map : results) {
                            String id = (String) map.get("__id__");
                            map.remove("__id__");
                            schedules.add(Schedule.fromMap(id, map));
                        }
                        callback.onSuccess(schedules);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        callback.onError(errorMessage);
                    }
                });
    }

    public void createSchedule(final Schedule schedule,
                               final FirebaseCallback<Schedule> callback) {
        new Thread(() -> {
            try {
                String docId = UUID.randomUUID().toString();
                schedule.id = docId;
                Map<String, Object> data = schedule.toMap();
                JSONObject fields = FirestoreDocument.toFirestoreFields(data);

                JSONObject body = new JSONObject();
                body.put("fields", fields);

                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_SCHEDULES
                        + "/" + docId + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpPatch(url, body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    callback.onError(json.getJSONObject("error").optString("message", "Create failed"));
                    return;
                }

                callback.onSuccess(Schedule.fromMap(docId, data));
            } catch (Exception e) {
                Log.e(TAG, "createSchedule error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to create schedule");
            }
        }).start();
    }

    /**
     * Update specific fields of a schedule document.
     */
    public void updateSchedule(final String id, final Map<String, Object> updates,
                               final FirebaseCallback<Schedule> callback) {
        updateDocument(Constants.COLLECTION_SCHEDULES, id, updates,
                new FirebaseCallback<Map<String, Object>>() {
                    @Override
                    public void onSuccess(Map<String, Object> result) {
                        String docId = (String) result.get("__id__");
                        result.remove("__id__");
                        callback.onSuccess(Schedule.fromMap(docId, result));
                    }

                    @Override
                    public void onError(String errorMessage) {
                        callback.onError(errorMessage);
                    }
                });
    }

    // =======================================================================
    // 5. ATTENDANCE CRUD
    // =======================================================================

    public void getAttendance(final FirebaseCallback<List<Attendance>> callback) {
        new Thread(() -> {
            try {
                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_ATTENDANCE
                        + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpGet(url);
                List<Attendance> attendance = FirestoreDocument.parseAttendances(new JSONObject(response));
                callback.onSuccess(attendance);
            } catch (Exception e) {
                Log.e(TAG, "getAttendance error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to get attendance");
            }
        }).start();
    }

    /**
     * Get attendance records filtered by userId.
     */
    public void getAttendanceByUser(final String userId,
                                    final FirebaseCallback<List<Attendance>> callback) {
        queryWhere(Constants.COLLECTION_ATTENDANCE, "userId", "EQUAL", userId,
                new FirebaseCallback<List<Map<String, Object>>>() {
                    @Override
                    public void onSuccess(List<Map<String, Object>> results) {
                        List<Attendance> list = new ArrayList<>();
                        for (Map<String, Object> map : results) {
                            String id = (String) map.get("__id__");
                            map.remove("__id__");
                            list.add(Attendance.fromMap(id, map));
                        }
                        callback.onSuccess(list);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        callback.onError(errorMessage);
                    }
                });
    }

    public void createAttendance(final Attendance attendance,
                                 final FirebaseCallback<Attendance> callback) {
        new Thread(() -> {
            try {
                String docId = UUID.randomUUID().toString();
                attendance.id = docId;
                Map<String, Object> data = attendance.toMap();
                JSONObject fields = FirestoreDocument.toFirestoreFields(data);

                JSONObject body = new JSONObject();
                body.put("fields", fields);

                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_ATTENDANCE
                        + "/" + docId + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpPatch(url, body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    callback.onError(json.getJSONObject("error").optString("message", "Create failed"));
                    return;
                }

                callback.onSuccess(Attendance.fromMap(docId, data));
            } catch (Exception e) {
                Log.e(TAG, "createAttendance error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to create attendance");
            }
        }).start();
    }

    // =======================================================================
    // 6. OVERTIME CRUD
    // =======================================================================

    public void getOvertime(final FirebaseCallback<List<Overtime>> callback) {
        new Thread(() -> {
            try {
                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_OVERTIME
                        + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpGet(url);
                List<Overtime> overtime = FirestoreDocument.parseOvertimes(new JSONObject(response));
                callback.onSuccess(overtime);
            } catch (Exception e) {
                Log.e(TAG, "getOvertime error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to get overtime");
            }
        }).start();
    }

    /**
     * Get overtime records filtered by userId.
     */
    public void getOvertimeByUser(final String userId,
                                  final FirebaseCallback<List<Overtime>> callback) {
        queryWhere(Constants.COLLECTION_OVERTIME, "userId", "EQUAL", userId,
                new FirebaseCallback<List<Map<String, Object>>>() {
                    @Override
                    public void onSuccess(List<Map<String, Object>> results) {
                        List<Overtime> list = new ArrayList<>();
                        for (Map<String, Object> map : results) {
                            String id = (String) map.get("__id__");
                            map.remove("__id__");
                            list.add(Overtime.fromMap(id, map));
                        }
                        callback.onSuccess(list);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        callback.onError(errorMessage);
                    }
                });
    }

    public void createOvertime(final Overtime overtime,
                               final FirebaseCallback<Overtime> callback) {
        new Thread(() -> {
            try {
                String docId = UUID.randomUUID().toString();
                overtime.id = docId;
                Map<String, Object> data = overtime.toMap();
                JSONObject fields = FirestoreDocument.toFirestoreFields(data);

                JSONObject body = new JSONObject();
                body.put("fields", fields);

                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_OVERTIME
                        + "/" + docId + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpPatch(url, body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    callback.onError(json.getJSONObject("error").optString("message", "Create failed"));
                    return;
                }

                callback.onSuccess(Overtime.fromMap(docId, data));
            } catch (Exception e) {
                Log.e(TAG, "createOvertime error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to create overtime");
            }
        }).start();
    }

    /**
     * Update overtime document fields (e.g. approve/reject).
     */
    public void updateOvertime(final String id, final Map<String, Object> updates,
                               final FirebaseCallback<Overtime> callback) {
        updateDocument(Constants.COLLECTION_OVERTIME, id, updates,
                new FirebaseCallback<Map<String, Object>>() {
                    @Override
                    public void onSuccess(Map<String, Object> result) {
                        String docId = (String) result.get("__id__");
                        result.remove("__id__");
                        callback.onSuccess(Overtime.fromMap(docId, result));
                    }

                    @Override
                    public void onError(String errorMessage) {
                        callback.onError(errorMessage);
                    }
                });
    }

    // =======================================================================
    // 7. FCM NOTIFICATIONS
    // =======================================================================

    /**
     * Send push notification via FCM legacy HTTP API.
     */
    public void sendNotification(final String title, final String body,
                                 final String targetToken,
                                 final FirebaseCallback<Boolean> callback) {
        new Thread(() -> {
            try {
                JSONObject notification = new JSONObject();
                notification.put("title", title);
                notification.put("body", body);
                notification.put("sound", "default");

                JSONObject payload = new JSONObject();
                payload.put("to", targetToken);
                payload.put("notification", notification);
                payload.put("priority", "high");

                String response = httpPostWithAuth(FCM_URL, payload.toString(),
                        "key=" + Constants.FCM_SERVER_KEY);

                JSONObject json = new JSONObject(response);
                if (json.has("error")) {
                    callback.onError(json.optString("error", "FCM send failed"));
                } else {
                    callback.onSuccess(true);
                }
            } catch (Exception e) {
                Log.e(TAG, "sendNotification error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to send notification");
            }
        }).start();
    }

    /**
     * Send notification to multiple devices (topic or multicast).
     */
    public void sendNotificationToTopic(final String title, final String body,
                                        final String topic,
                                        final FirebaseCallback<Boolean> callback) {
        new Thread(() -> {
            try {
                JSONObject notification = new JSONObject();
                notification.put("title", title);
                notification.put("body", body);
                notification.put("sound", "default");

                JSONObject payload = new JSONObject();
                payload.put("to", "/topics/" + topic);
                payload.put("notification", notification);
                payload.put("priority", "high");

                String response = httpPostWithAuth(FCM_URL, payload.toString(),
                        "key=" + Constants.FCM_SERVER_KEY);

                JSONObject json = new JSONObject(response);
                if (json.has("error")) {
                    callback.onError(json.optString("error", "FCM send failed"));
                } else {
                    callback.onSuccess(true);
                }
            } catch (Exception e) {
                Log.e(TAG, "sendNotificationToTopic error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to send notification");
            }
        }).start();
    }

    // =======================================================================
    // INTERNAL HELPERS
    // =======================================================================

    /**
     * List all documents from a collection and parse them into model objects
     * using the provided parser function.
     */
    private <T> void listCollection(final String collection,
                                    final FirebaseCallback<List<T>> callback) {
        new Thread(() -> {
            try {
                String url = FIRESTORE_BASE + "/" + collection
                        + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpGet(url);
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    callback.onError(json.getJSONObject("error").optString("message", "List failed"));
                    return;
                }

                List<T> results = new ArrayList<>();
                JSONArray docs = json.optJSONArray("documents");
                if (docs != null) {
                    for (int i = 0; i < docs.length(); i++) {
                        JSONObject doc = docs.getJSONObject(i);
                        T parsed = FirestoreDocument.parseDocument(collection, doc);
                        if (parsed != null) {
                            results.add(parsed);
                        }
                    }
                }
                callback.onSuccess(results);
            } catch (Exception e) {
                Log.e(TAG, "listCollection error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to list " + collection);
            }
        }).start();
    }

    /**
     * Update a specific document's fields using PATCH.
     */
    private void updateDocument(final String collection, final String docId,
                                final Map<String, Object> updates,
                                final FirebaseCallback<Map<String, Object>> callback) {
        new Thread(() -> {
            try {
                JSONObject fields = FirestoreDocument.toFirestoreFields(updates);
                JSONObject body = new JSONObject();
                body.put("fields", fields);

                String url = FIRESTORE_BASE + "/" + collection + "/" + docId
                        + "?key=" + Constants.FIREBASE_API_KEY
                        + "&updateMask.fieldPaths=" + String.join("&updateMask.fieldPaths=",
                        updates.keySet());

                String response = httpPatch(url, body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    callback.onError(json.getJSONObject("error").optString("message", "Update failed"));
                    return;
                }

                Map<String, Object> result = FirestoreDocument.fromFirestoreFields(
                        json.optJSONObject("fields"));
                result.put("__id__", extractDocId(json));
                callback.onSuccess(result);
            } catch (Exception e) {
                Log.e(TAG, "updateDocument error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to update document");
            }
        }).start();
    }

    /**
     * Create user document in Firestore.
     */
    private void createUserDocument(final User user,
                                    final FirebaseCallback<User> callback) {
        new Thread(() -> {
            try {
                Map<String, Object> data = user.toMap();
                JSONObject fields = FirestoreDocument.toFirestoreFields(data);
                JSONObject body = new JSONObject();
                body.put("fields", fields);

                String url = FIRESTORE_BASE + "/" + Constants.COLLECTION_USERS
                        + "/" + user.id + "?key=" + Constants.FIREBASE_API_KEY;
                String response = httpPatch(url, body.toString());
                JSONObject json = new JSONObject(response);

                if (json.has("error")) {
                    callback.onError(json.getJSONObject("error").optString("message", "Create user failed"));
                    return;
                }

                callback.onSuccess(user);
            } catch (Exception e) {
                Log.e(TAG, "createUserDocument error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Failed to create user");
            }
        }).start();
    }

    /**
     * Query documents with a simple where filter using Firestore runQuery.
     * Supports operators: "EQUAL", "GREATER_THAN", "GREATER_THAN_OR_EQUAL",
     * "LESS_THAN", "LESS_THAN_OR_EQUAL", "ARRAY_CONTAINS".
     */
    private void queryWhere(final String collection, final String field,
                            final String operator, final String value,
                            final FirebaseCallback<List<Map<String, Object>>> callback) {
        new Thread(() -> {
            try {
                JSONObject fieldRef = new JSONObject();
                fieldRef.put("fieldPath", field);

                JSONObject fieldValue = new JSONObject();
                fieldValue.put("stringValue", value);

                JSONObject fieldFilter = new JSONObject();
                fieldFilter.put("field", fieldRef);
                fieldFilter.put("op", operator);
                fieldFilter.put("value", fieldValue);

                JSONObject where = new JSONObject();
                where.put("fieldFilter", fieldFilter);

                JSONObject fromItem = new JSONObject();
                fromItem.put("collectionId", collection);

                JSONArray from = new JSONArray();
                from.put(fromItem);

                JSONObject structuredQuery = new JSONObject();
                structuredQuery.put("from", from);
                structuredQuery.put("where", where);

                JSONObject body = new JSONObject();
                body.put("structuredQuery", structuredQuery);

                String response = httpPost(FIRESTORE_RUN_QUERY, body.toString());
                JSONArray results = new JSONArray(response);

                List<Map<String, Object>> parsed = new ArrayList<>();
                for (int i = 0; i < results.length(); i++) {
                    JSONObject item = results.getJSONObject(i);
                    if (item.has("document")) {
                        JSONObject doc = item.getJSONObject("document");
                        Map<String, Object> fields = FirestoreDocument.fromFirestoreFields(
                                doc.optJSONObject("fields"));
                        if (fields != null) {
                            fields.put("__id__", extractDocId(doc));
                            parsed.add(fields);
                        }
                    }
                }
                callback.onSuccess(parsed);
            } catch (Exception e) {
                Log.e(TAG, "queryWhere error", e);
                callback.onError(e.getMessage() != null ? e.getMessage() : "Query failed");
            }
        }).start();
    }

    /**
     * Extract document ID from the Firestore document's "name" field.
     * name format: projects/{project}/databases/(default)/documents/{collection}/{docId}
     */
    private static String extractDocId(JSONObject doc) {
        String name = doc.optString("name", "");
        if (name.isEmpty()) return "";
        int lastSlash = name.lastIndexOf('/');
        return lastSlash >= 0 ? name.substring(lastSlash + 1) : name;
    }

    // =======================================================================
    // HTTP CLIENT
    // =======================================================================

    private static String httpGet(String urlString) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);

            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) {
                return readStream(conn.getInputStream());
            } else {
                String error = readStream(conn.getErrorStream());
                Log.w(TAG, "GET " + code + ": " + error);
                return error;
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String httpPost(String urlString, String jsonBody) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);
            conn.setDoOutput(true);

            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            os.writeBytes(jsonBody);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) {
                return readStream(conn.getInputStream());
            } else {
                String error = readStream(conn.getErrorStream());
                Log.w(TAG, "POST " + code + ": " + error);
                return error;
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String httpPatch(String urlString, String jsonBody) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("X-HTTP-Method-Override", "PATCH");
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);
            conn.setDoOutput(true);

            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            os.writeBytes(jsonBody);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) {
                return readStream(conn.getInputStream());
            } else {
                String error = readStream(conn.getErrorStream());
                Log.w(TAG, "PATCH " + code + ": " + error);
                return error;
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String httpPostWithAuth(String urlString, String jsonBody,
                                           String authHeader) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Authorization", authHeader);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);
            conn.setDoOutput(true);

            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            os.writeBytes(jsonBody);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) {
                return readStream(conn.getInputStream());
            } else {
                String error = readStream(conn.getErrorStream());
                Log.w(TAG, "POST_AUTH " + code + ": " + error);
                return error;
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        return sb.toString();
    }

    // =======================================================================
    // 8. FirestoreDocument HELPER
    // =======================================================================

    /**
     * Utility class that converts between Firestore REST API field format
     * (fields with typed values like {"stringValue": "..."}) and simple
     * Java Map<String, Object>, and parses Firestore documents into model objects.
     */
    public static class FirestoreDocument {

        /**
         * Convert Firestore REST "fields" JSON object to a simple Map<String, Object>.
         * Handles: stringValue, integerValue, doubleValue, booleanValue,
         * timestampValue, referenceValue, nullValue, arrayValue, mapValue.
         */
        public static Map<String, Object> fromFirestoreFields(JSONObject fields) throws Exception {
            if (fields == null) return new HashMap<>();
            Map<String, Object> result = new HashMap<>();
            Iterator<String> keys = fields.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject valueObj = fields.getJSONObject(key);
                result.put(key, extractValue(valueObj));
            }
            return result;
        }

        /**
         * Convert a simple Map<String, Object> to Firestore REST "fields" JSON object.
         */
        public static JSONObject toFirestoreFields(Map<String, Object> data) throws Exception {
            JSONObject fields = new JSONObject();
            for (Map.Entry<String, Object> entry : data.entrySet()) {
                if (entry.getValue() == null) continue;
                fields.put(entry.getKey(), toTypedValue(entry.getValue()));
            }
            return fields;
        }

        /**
         * Parse a single Firestore typed value into a Java object.
         */
        private static Object extractValue(JSONObject typed) throws Exception {
            if (typed == null) return null;

            // Scalar types
            if (typed.has("stringValue")) return typed.getString("stringValue");
            if (typed.has("integerValue")) {
                String raw = typed.getString("integerValue");
                try {
                    return Long.parseLong(raw);
                } catch (NumberFormatException e) {
                    return raw;
                }
            }
            if (typed.has("doubleValue")) return typed.getDouble("doubleValue");
            if (typed.has("booleanValue")) return typed.getBoolean("booleanValue");
            if (typed.has("nullValue")) return null;
            if (typed.has("referenceValue")) return typed.getString("referenceValue");

            // Timestamp: return ISO string representation
            if (typed.has("timestampValue")) return typed.getString("timestampValue");

            // Array: recursively parse each element
            if (typed.has("arrayValue")) {
                JSONObject arrayObj = typed.getJSONObject("arrayValue");
                JSONArray values = arrayObj.optJSONArray("values");
                List<Object> list = new ArrayList<>();
                if (values != null) {
                    for (int i = 0; i < values.length(); i++) {
                        list.add(extractValue(values.getJSONObject(i)));
                    }
                }
                return list;
            }

            // Map: recursively parse each field
            if (typed.has("mapValue")) {
                JSONObject mapObj = typed.getJSONObject("mapValue");
                JSONObject nestedFields = mapObj.optJSONObject("fields");
                return fromFirestoreFields(nestedFields);
            }

            return null;
        }

        /**
         * Convert a Java value to a Firestore typed value JSON object.
         */
        private static JSONObject toTypedValue(Object value) throws Exception {
            JSONObject typed = new JSONObject();
            if (value instanceof String) {
                typed.put("stringValue", value);
            } else if (value instanceof Integer) {
                typed.put("integerValue", String.valueOf(value));
            } else if (value instanceof Long) {
                typed.put("integerValue", String.valueOf(value));
            } else if (value instanceof Float) {
                typed.put("doubleValue", ((Float) value).doubleValue());
            } else if (value instanceof Double) {
                typed.put("doubleValue", value);
            } else if (value instanceof Boolean) {
                typed.put("booleanValue", value);
            } else if (value instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> map = (Map<String, Object>) value;
                JSONObject nestedFields = toFirestoreFields(map);
                JSONObject mapValue = new JSONObject();
                mapValue.put("fields", nestedFields);
                typed.put("mapValue", mapValue);
            } else if (value instanceof List) {
                List<?> list = (List<?>) value;
                JSONArray arr = new JSONArray();
                for (Object item : list) {
                    arr.put(toTypedValue(item));
                }
                JSONObject arrayValue = new JSONObject();
                arrayValue.put("values", arr);
                typed.put("arrayValue", arrayValue);
            } else {
                // Fallback: toString as stringValue
                typed.put("stringValue", value.toString());
            }
            return typed;
        }

        /**
         * Parse a single Firestore document JSON into the appropriate model object
         * based on collection name extracted from the document's "name" field.
         */
        @SuppressWarnings("unchecked")
        public static <T> T parseDocument(String collection, JSONObject doc) throws Exception {
            String docId = extractDocId(doc);
            JSONObject fields = doc.optJSONObject("fields");
            if (fields == null) return null;

            Map<String, Object> map = fromFirestoreFields(fields);

            switch (collection) {
                case Constants.COLLECTION_USERS:
                    return (T) User.fromMap(docId, map);
                case Constants.COLLECTION_SHIFTS:
                    return (T) Shift.fromMap(docId, map);
                case Constants.COLLECTION_SCHEDULES:
                    return (T) Schedule.fromMap(docId, map);
                case Constants.COLLECTION_ATTENDANCE:
                    return (T) Attendance.fromMap(docId, map);
                case Constants.COLLECTION_OVERTIME:
                    return (T) Overtime.fromMap(docId, map);
                default:
                    return (T) map;
            }
        }

        // ---- Convenience parsers for model lists ----

        public static List<User> parseUsers(JSONObject response) throws Exception {
            List<User> list = new ArrayList<>();
            JSONArray docs = response.optJSONArray("documents");
            if (docs != null) {
                for (int i = 0; i < docs.length(); i++) {
                    User u = parseDocument(Constants.COLLECTION_USERS, docs.getJSONObject(i));
                    if (u != null) list.add(u);
                }
            }
            return list;
        }

        public static User parseUser(JSONObject doc) throws Exception {
            return parseDocument(Constants.COLLECTION_USERS, doc);
        }

        public static List<Shift> parseShifts(JSONObject response) throws Exception {
            List<Shift> list = new ArrayList<>();
            JSONArray docs = response.optJSONArray("documents");
            if (docs != null) {
                for (int i = 0; i < docs.length(); i++) {
                    Shift s = parseDocument(Constants.COLLECTION_SHIFTS, docs.getJSONObject(i));
                    if (s != null) list.add(s);
                }
            }
            return list;
        }

        public static List<Schedule> parseSchedules(JSONObject response) throws Exception {
            List<Schedule> list = new ArrayList<>();
            JSONArray docs = response.optJSONArray("documents");
            if (docs != null) {
                for (int i = 0; i < docs.length(); i++) {
                    Schedule s = parseDocument(Constants.COLLECTION_SCHEDULES, docs.getJSONObject(i));
                    if (s != null) list.add(s);
                }
            }
            return list;
        }

        public static List<Attendance> parseAttendances(JSONObject response) throws Exception {
            List<Attendance> list = new ArrayList<>();
            JSONArray docs = response.optJSONArray("documents");
            if (docs != null) {
                for (int i = 0; i < docs.length(); i++) {
                    Attendance a = parseDocument(Constants.COLLECTION_ATTENDANCE, docs.getJSONObject(i));
                    if (a != null) list.add(a);
                }
            }
            return list;
        }

        public static List<Overtime> parseOvertimes(JSONObject response) throws Exception {
            List<Overtime> list = new ArrayList<>();
            JSONArray docs = response.optJSONArray("documents");
            if (docs != null) {
                for (int i = 0; i < docs.length(); i++) {
                    Overtime o = parseDocument(Constants.COLLECTION_OVERTIME, docs.getJSONObject(i));
                    if (o != null) list.add(o);
                }
            }
            return list;
        }
    }
}
