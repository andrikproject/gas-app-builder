package com.bankaltimtara.satpam.models;

import java.util.HashMap;
import java.util.Map;

public class Shift {
    public String id, nama, jamMulai, jamSelesai, kategori; // kategori: "8jam" / "12jam"
    public int durasiJam;

    public Shift() {}

    public Shift(String id, String nama, String jamMulai, String jamSelesai, String kategori) {
        this.id = id; this.nama = nama; this.jamMulai = jamMulai;
        this.jamSelesai = jamSelesai; this.kategori = kategori;
        this.durasiJam = hitungDurasi();
    }

    public int hitungDurasi() {
        try {
            int mulai = Integer.parseInt(jamMulai.split(":")[0]);
            int selesai = Integer.parseInt(jamSelesai.split(":")[0]);
            return selesai > mulai ? selesai - mulai : (24 - mulai) + selesai;
        } catch (Exception e) { return 8; }
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("nama", nama); m.put("jamMulai", jamMulai);
        m.put("jamSelesai", jamSelesai); m.put("kategori", kategori);
        m.put("durasiJam", durasiJam);
        return m;
    }

    public static Shift fromMap(String id, Map<String, Object> m) {
        Shift s = new Shift();
        s.id = id; s.nama = (String) m.get("nama");
        s.jamMulai = (String) m.get("jamMulai"); s.jamSelesai = (String) m.get("jamSelesai");
        s.kategori = (String) m.get("kategori");
        s.durasiJam = m.containsKey("durasiJam") ? ((Long) m.get("durasiJam")).intValue() : s.hitungDurasi();
        return s;
    }

    // Shift default
    public static Shift[] getDefaultShifts() {
        return new Shift[] {
            new Shift("shift_pagi", "Pagi", "06:00", "14:00", "8jam"),
            new Shift("shift_siang", "Siang", "14:00", "22:00", "8jam"),
            new Shift("shift_malam", "Malam", "22:00", "06:00", "8jam"),
            new Shift("shift_reguler", "Reguler 12 Jam", "07:00", "19:00", "12jam"),
            new Shift("shift_malam12", "Malam 12 Jam", "19:00", "07:00", "12jam")
        };
    }
}
