package com.bankaltimtara.satpam.models;

import java.util.HashMap;
import java.util.Map;

public class Attendance {
    public String id, userId, userName, tanggal, shift, status;
    public String checkInTime, checkOutTime, lokasiMasuk, lokasiKeluar;
    public double jamKerja, jamLembur;
    public long timestamp;

    public static final String STATUS_HADIR = "hadir";
    public static final String STATUS_TERLAMBAT = "terlambat";
    public static final String STATUS_ALPA = "alpa";
    public static final String STATUS_CUTI = "cuti";
    public static final String STATUS_IZIN = "izin";
    public static final String STATUS_LEMBUR = "lembur";

    public Attendance() {}

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("userId", userId); m.put("userName", userName);
        m.put("tanggal", tanggal); m.put("shift", shift);
        m.put("status", status); m.put("checkInTime", checkInTime);
        m.put("checkOutTime", checkOutTime); m.put("lokasiMasuk", lokasiMasuk);
        m.put("lokasiKeluar", lokasiKeluar);
        m.put("jamKerja", jamKerja); m.put("jamLembur", jamLembur);
        m.put("timestamp", timestamp != 0 ? timestamp : System.currentTimeMillis());
        return m;
    }

    public static Attendance fromMap(String id, Map<String, Object> m) {
        Attendance a = new Attendance();
        a.id = id; a.userId = (String) m.get("userId"); a.userName = (String) m.get("userName");
        a.tanggal = (String) m.get("tanggal"); a.shift = (String) m.get("shift");
        a.status = (String) m.get("status"); a.checkInTime = (String) m.get("checkInTime");
        a.checkOutTime = (String) m.get("checkOutTime");
        a.lokasiMasuk = (String) m.get("lokasiMasuk"); a.lokasiKeluar = (String) m.get("lokasiKeluar");
        if (m.containsKey("jamKerja")) a.jamKerja = m.get("jamKerja") instanceof Double ?
            (Double) m.get("jamKerja") : ((Long) m.get("jamKerja")).doubleValue();
        if (m.containsKey("jamLembur")) a.jamLembur = m.get("jamLembur") instanceof Double ?
            (Double) m.get("jamLembur") : ((Long) m.get("jamLembur")).doubleValue();
        if (m.containsKey("timestamp")) a.timestamp = (Long) m.get("timestamp");
        return a;
    }

    public String getStatusIcon() {
        switch (status == null ? "" : status) {
            case "hadir": return "✅";
            case "terlambat": return "⚠️";
            case "alpa": return "❌";
            case "cuti": return "🏖️";
            case "izin": return "📝";
            case "lembur": return "💪";
            default: return "❓";
        }
    }
}
