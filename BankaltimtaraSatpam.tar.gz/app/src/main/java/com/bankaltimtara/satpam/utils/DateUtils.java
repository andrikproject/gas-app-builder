package com.bankaltimtara.satpam.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtils {
    public static final String FORMAT_TANGGAL = "yyyy-MM-dd";
    public static final String FORMAT_JAM = "HH:mm";
    public static final String FORMAT_LENGKAP = "yyyy-MM-dd HH:mm:ss";
    public static final String FORMAT_INDONESIA = "EEEE, dd MMMM yyyy";
    public static final Locale LOCALE_ID = new Locale("id", "ID");

    public static String now(String format) {
        return new SimpleDateFormat(format, LOCALE_ID).format(new Date());
    }

    public static String today() { return now(FORMAT_TANGGAL); }
    public static String nowTime() { return now(FORMAT_JAM); }
    public static String nowFull() { return now(FORMAT_LENGKAP); }

    public static String formatTanggal(String tanggal) {
        try {
            Date d = new SimpleDateFormat(FORMAT_TANGGAL, LOCALE_ID).parse(tanggal);
            return new SimpleDateFormat(FORMAT_INDONESIA, LOCALE_ID).format(d);
        } catch (Exception e) { return tanggal; }
    }

    public static String getHari(String tanggal) {
        try {
            Date d = new SimpleDateFormat(FORMAT_TANGGAL, LOCALE_ID).parse(tanggal);
            return new SimpleDateFormat("EEEE", LOCALE_ID).format(d);
        } catch (Exception e) { return ""; }
    }

    public static String tambahHari(String tanggal, int hari) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_TANGGAL, LOCALE_ID);
            Calendar c = Calendar.getInstance();
            c.setTime(sdf.parse(tanggal));
            c.add(Calendar.DAY_OF_MONTH, hari);
            return sdf.format(c.getTime());
        } catch (Exception e) { return tanggal; }
    }

    public static boolean isAkhirPekan(String tanggal) {
        String hari = getHari(tanggal);
        return hari.equalsIgnoreCase("Sabtu") || hari.equalsIgnoreCase("Minggu") ||
               hari.equalsIgnoreCase("Saturday") || hari.equalsIgnoreCase("Sunday");
    }

    public static String[] getRangeBulan(int tahun, int bulan) {
        Calendar c = Calendar.getInstance();
        c.set(tahun, bulan - 1, 1);
        String awal = new SimpleDateFormat(FORMAT_TANGGAL).format(c.getTime());
        c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
        String akhir = new SimpleDateFormat(FORMAT_TANGGAL).format(c.getTime());
        return new String[]{awal, akhir};
    }

    public static long hitungJamLembur(String jamMulaiShift, String jamSelesaiShift, String checkIn, String checkOut) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            Date in = sdf.parse(checkIn);
            Date out = sdf.parse(checkOut);
            Date shiftMulai = sdf.parse(jamMulaiShift);
            Date shiftSelesai = sdf.parse(jamSelesaiShift);

            long durasiShift = shiftSelesai.getTime() - shiftMulai.getTime();
            if (durasiShift < 0) durasiShift += 24 * 60 * 60 * 1000;

            long durasiKerja = out.getTime() - in.getTime();
            if (durasiKerja < 0) durasiKerja += 24 * 60 * 60 * 1000;

            long lembur = durasiKerja - durasiShift;
            return lembur > 0 ? lembur / (1000 * 60 * 60) : 0;
        } catch (Exception e) { return 0; }
    }
}
