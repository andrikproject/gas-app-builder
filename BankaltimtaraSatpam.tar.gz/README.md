# Bankaltimtara Satpam - Aplikasi Manajemen Jadwal Kerja Satpam

## 📱 Fitur Lengkap

| Fitur | Keterangan |
|-------|------------|
| ✅ **Login Multi-Role** | Admin & Satpam dengan Firebase Auth |
| ✅ **Dashboard Interaktif** | Statistik real-time, shift hari ini |
| ✅ **Generate Jadwal Otomatis** | Input manual admin → otomatis generate jadwal |
| ✅ **Shift 8 Jam & 12 Jam** | Pagi (06-14), Siang (14-22), Malam (22-06), Reguler (07-19), Malam 12J (19-07) |
| ✅ **Rotasi Pintar** | Distribusi shift adil, hari libur otomatis, minimal 1 hari libur/minggu |
| ✅ **Absensi Check-in/out** | Dengan lokasi GPS dan timestamp otomatis |
| ✅ **Rekap Kehadiran Harian** | Monitoring real-time siapa yang hadir/terlambat/alpa |
| ✅ **Laporan Lembur** | Hitung otomatis, langsung ke penggajian |
| ✅ **Notifikasi Push** | Pengingat shift, perubahan jadwal, approval lembur |
| ✅ **Notifikasi Email** | Notifikasi ke surel untuk event penting |
| ✅ **Manajemen User** | Admin bisa tambah/edit/nonaktifkan petugas |
| ✅ **Evaluasi Kinerja** | Dashboard analitik, statistik per bulan |
| ✅ **Ekspor Laporan** | Support format yang bisa dibuka di Excel/PDF |
| ✅ **UI Modern Minimalis** | Material Design 3, mudah digunakan tanpa pelatihan |

## 🏗️ Arsitektur Aplikasi

```
BankaltimtaraSatpam/
├── app/src/main/java/com/bankaltimtara/satpam/
│   ├── models/           # Data model (User, Shift, Schedule, etc.)
│   ├── services/         # Firebase, ScheduleGenerator, Notifications
│   ├── utils/            # DateUtils, Constants, PreferencesManager
│   ├── admin/            # Admin activity (dashboard, schedule, users, etc.)
│   ├── LoginActivity.java
│   ├── MainActivity.java
│   ├── DashboardActivity.java
│   ├── ScheduleActivity.java
│   ├── AttendanceActivity.java
│   ├── ReportActivity.java
│   ├── ProfileActivity.java
│   └── MyFirebaseMessagingService.java
└── app/src/main/res/     # Layout XML, values, drawable, menu
```

## 🔧 Cara Setup & Build

### Prasyarat
- Android Studio (atau AIDE di HP)
- Akun Firebase (gratis)
- Koneksi internet

### Langkah 1: Buat Project Firebase
1. Buka https://console.firebase.google.com
2. Klik **+ Add project** → beri nama (misal: "bankaltimtara-satpam")
3. Ikuti wizard → **Create project**

### Langkah 2: Register Aplikasi Android
1. Di Firebase Console → **Android icon** (+ Add app)
2. Package name: `com.bankaltimtara.satpam`
3. App nickname: "Bankaltimtara Satpam"
4. Klik **Register app**
5. **Download google-services.json**

### Langkah 3: Ganti File Konfigurasi
1. Copy `google-services.json` yang didownload ke:
   ```
   BankaltimtaraSatpam/app/google-services.json
   ```
2. Buka file `BankaltimtaraSatpam/app/src/main/java/com/bankaltimtara/satpam/utils/Constants.java`
3. Ganti `YOUR_FIREBASE_WEB_API_KEY` dengan Web API Key dari Firebase:
   ```
   Firebase Console → Project Settings → General → Web API Key
   ```
4. Ganti `YOUR_PROJECT_ID` dengan Project ID Firebase-mu

### Langkah 4: Aktifkan Firebase Services
Di Firebase Console, aktifkan:

| Service | Cara |
|---------|------|
| 🔐 **Authentication** | Authentication → Sign-in method → **Email/Password** → Enable |
| 📦 **Cloud Firestore** | Firestore Database → **Create database** → Start in **test mode** |
| 📨 **Cloud Messaging** | Cloud Messaging → sudah aktif otomatis |

### Langkah 5: Build & Install
#### Pakai Android Studio (PC):
```
cd BankaltimtaraSatpam
./gradlew assembleDebug
```
Hasil APK: `app/build/outputs/apk/debug/app-debug.apk`

#### Pakai AIDE (HP):
1. Copy folder ke HP
2. Buka AIDE → Open project → pilih folder
3. Tap **Run** (▶️) → Install APK

### Langkah 6: Setup Awal di Aplikasi
1. Buka aplikasi → **Register akun Admin pertama**
   - Email: admin@bankaltimtara.com
   - Password: minimal 6 karakter
   - Nama: "Admin Bankaltimtara"
2. Login dengan akun admin
3. Buka **Shift** → Klik **+** → Tambah shift default:
   - Pagi (06:00-14:00) 8 jam
   - Siang (14:00-22:00) 8 jam
   - Malam (22:00-06:00) 8 jam
   - Reguler 12 Jam (07:00-19:00)
   - Malam 12 Jam (19:00-07:00)
4. Buka **Users** → **+** → Tambah petugas satpam
5. Buka **Schedule** → Pilih tanggal → Klik **Generate** → Jadwal otomatis terbuat!

## 🎯 Fitur Notifikasi

### Push Notification (FCM)
Notifikasi otomatis dikirim saat:

| Event | Waktu | Channel |
|-------|-------|---------|
| 🔔 **Pengingat Shift** | 30 menit sebelum shift | Shift Reminder |
| 🔔 **Perubahan Jadwal** | Saat admin merubah jadwal | Schedule Change |
| 🔔 **Approval Lembur** | Saat lembur disetujui/ditolak | Overtime |
| 🔔 **Pengumuman** | Dari admin ke semua petugas | General |

### Notifikasi Email
Untuk event penting, kirim notifikasi ke email:
- Perubahan jadwal mendadak
- Approval lembur
- Laporan bulanan

Setup di Firebase Console:
```
Firebase → Extensions → Trigger Email
```

## 📊 Struktur Database Firestore

```
bankaltimtara-satpam/
├── users/                    # Data pengguna
│   ├── {userId}/
│   │   ├── name: "Budi"
│   │   ├── email: "budi@email.com"
│   │   ├── role: "satpam" / "admin"
│   │   ├── nip: "SATPAM-001"
│   │   ├── posisi: "Satpam Bankaltimtara"
│   │   └── aktif: true
├── shifts/                   # Konfigurasi shift
│   ├── {shiftId}/
│   │   ├── nama: "Pagi"
│   │   ├── jamMulai: "06:00"
│   │   ├── jamSelesai: "14:00"
│   │   ├── kategori: "8jam" / "12jam"
│   │   └── durasiJam: 8
├── schedules/                # Jadwal kerja
│   ├── {scheduleId}/
│   │   ├── userId: "..."
│   │   ├── userName: "Budi"
│   │   ├── shiftId: "..."
│   │   ├── shiftNama: "Pagi"
│   │   ├── tanggal: "2026-06-07"
│   │   ├── status: "terjadwal"
│   │   └── createdAt: timestamp
├── attendance/               # Absensi
│   ├── {attendanceId}/
│   │   ├── userId: "..."
│   │   ├── userName: "Budi"
│   │   ├── tanggal: "2026-06-07"
│   │   ├── shift: "Pagi"
│   │   ├── status: "hadir" / "terlambat" / "alpa"
│   │   ├── checkInTime: "06:05"
│   │   ├── checkOutTime: "14:10"
│   │   ├── lokasiMasuk: "..."
│   │   ├── lokasiKeluar: "..."
│   │   ├── jamKerja: 8.0
│   │   ├── jamLembur: 0.5
│   │   └── timestamp: timestamp
├── overtime/                 # Lembur
│   ├── {overtimeId}/
│   │   ├── userId: "..."
│   │   ├── userName: "Budi"
│   │   ├── tanggal: "..."
│   │   ├── shift: "Pagi"
│   │   ├── alasan: "Tugas tambahan"
│   │   ├── durasiJam: 2.0
│   │   ├── tarifLembur: 35000
│   │   ├── totalBayaran: 70000
│   │   ├── status: "pending" / "disetujui" / "ditolak"
│   │   └── createdAt: timestamp
└── notifications/            # History notifikasi
    └── ...
```

## 🔄 Siklus Penggunaan Harian

```
PAGI (05:30)
  → Notifikasi: "Shift Pagi Anda dimulai pukul 06:00" 🔔
  → Petugas datang → Buka app → Check-in (GPS + selfie)

SIANG (14:00)
  → Check-out shift Pagi
  → Jika lembur: otomatis terdeteksi
  → Notifikasi ke admin: "Budi lembur 1 jam"

MALAM (22:00)
  → Shift malam check-in
  → Admin lihat dashboard real-time

AKHIR BULAN
  → Admin buka Laporan
  → Filter bulan → Lihat statistik
  → Export untuk payroll
  → Evaluasi kinerja satpam
```

## 🚀 Deployment & Scaling

Untuk production:
1. **Firebase Security Rules** — Atur rules Firestore
2. **Cloud Functions** — Jadwalkan notifikasi otomatis
3. **Indexing** — Buat composite index di Firestore
4. **ProGuard** — Minify untuk production APK
5. **Play Console** — Upload ke Google Play Store

## 📞 Kontak & Dukungan

Dikembangkan oleh tim IT Bankaltimtara.
Untuk pertanyaan: it-support@bankaltimtara.com
