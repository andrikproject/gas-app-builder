package com.bankaltimtara.satpam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.bankaltimtara.satpam.models.User;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.snackbar.Snackbar;

public class ProfileActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private TextView tvNama, tvEmail, tvRole, tvNip, tvPosisi;
    private Button btnEditProfil, btnLogout;

    private PreferencesManager preferencesManager;
    private FirebaseService firebaseService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Profil Saya");
        }

        progressBar = findViewById(R.id.progressBar);
        tvNama = findViewById(R.id.tvNama);
        tvEmail = findViewById(R.id.tvEmail);
        tvRole = findViewById(R.id.tvRole);
        tvNip = findViewById(R.id.tvNip);
        tvPosisi = findViewById(R.id.tvPosisi);
        btnEditProfil = findViewById(R.id.btnEditProfil);
        btnLogout = findViewById(R.id.btnLogout);

        preferencesManager = PreferencesManager.getInstance(this);
        firebaseService = FirebaseService.getInstance(this);

        loadProfile();

        btnEditProfil.setOnClickListener(v -> showEditDialog());
        btnLogout.setOnClickListener(v -> showLogoutConfirm());
    }

    private void loadProfile() {
        User user = preferencesManager.getUser();
        if (user != null) {
            tvNama.setText(user.name != null && !user.name.isEmpty() ? user.name : "-");
            tvEmail.setText(user.email != null && !user.email.isEmpty() ? user.email : "-");
            String role = user.role != null ? user.role : "satpam";
            tvRole.setText(role.equalsIgnoreCase("admin") ? "Admin" : "Satpam");
            tvNip.setText(user.nip != null && !user.nip.isEmpty() ? user.nip : "-");
            tvPosisi.setText(user.posisi != null && !user.posisi.isEmpty() ? user.posisi : "-");
        }
    }

    private void showEditDialog() {
        User user = preferencesManager.getUser();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Profil");

        View view = getLayoutInflater().inflate(R.layout.dialog_edit_profil, null);
        EditText edtNama = view.findViewById(R.id.edtNama);
        EditText edtNip = view.findViewById(R.id.edtNip);
        EditText edtPosisi = view.findViewById(R.id.edtPosisi);

        if (user != null) {
            edtNama.setText(user.name);
            edtNip.setText(user.nip);
            edtPosisi.setText(user.posisi);
        }

        builder.setView(view);
        builder.setPositiveButton("Simpan", (dialog, which) -> {
            String nama = edtNama.getText().toString().trim();
            String nip = edtNip.getText().toString().trim();
            String posisi = edtPosisi.getText().toString().trim();

            if (nama.isEmpty()) {
                Toast.makeText(this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            showLoading(true);
            java.util.HashMap<String, Object> updates = new java.util.HashMap<>();
            updates.put("name", nama);
            updates.put("nip", nip);
            updates.put("posisi", posisi);

            firebaseService.getUserById(preferencesManager.getUserId(),
                    new FirebaseService.FirebaseCallback<User>() {
                        @Override
                        public void onSuccess(User user) {
                            runOnUiThread(() -> {
                                showLoading(false);
                                preferencesManager.setUserName(nama);
                                if (!nip.isEmpty()) {
                                    preferencesManager.setUserRole(nip);
                                }
                                loadProfile();
                                Snackbar.make(coordinatorLayout,
                                        "Profil berhasil diperbarui", Snackbar.LENGTH_LONG).show();
                            });
                        }

                        @Override
                        public void onError(String errorMessage) {
                            runOnUiThread(() -> {
                                showLoading(false);
                                Snackbar.make(coordinatorLayout,
                                        "Gagal memperbarui profil: " + errorMessage,
                                        Snackbar.LENGTH_LONG).show();
                            });
                        }
                    });
        });
        builder.setNegativeButton("Batal", null);
        builder.show();
    }

    private void showLogoutConfirm() {
        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Logout")
                .setMessage("Apakah Anda yakin ingin keluar?")
                .setPositiveButton("Ya", (dialog, which) -> logout())
                .setNegativeButton("Batal", null)
                .show();
    }

    private void logout() {
        preferencesManager.logout();
        Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
