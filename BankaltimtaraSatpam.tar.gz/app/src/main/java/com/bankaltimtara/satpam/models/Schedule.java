package com.bankaltimtara.satpam.models;

import java.util.HashMap;
import java.util.Map;

public class Schedule {
    public String id, userId, userName, shiftId, shiftNama, tanggal, status;
    // status: "terjadwal", "checkin", "checkout", "alpa", "libur", "cuti"
    public String checkInTime, checkOutTime, checkInFoto, checkOutFoto, checkInLokasi, checkOutLokasi;
    public long checkInTimestamp, checkOutTimestamp, createdAt;
    public double jamLembur; // dalam jam

    public Schedule() {}

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("userId", userId); m.put("userName", userName);
        m.put("shiftId", shiftId); m.put("shiftNama", shiftNama);
        m.put("tanggal", tanggal); m.put("status", status != null ? status : "terjadwal");
        m.put("checkInTime", checkInTime); m.put("checkOutTime", checkOutTime);
        m.put("checkInFoto", checkInFoto); m.put("checkOutFoto", checkOutFoto);
        m.put("checkInLokasi", checkInLokasi); m.put("checkOutLokasi", checkOutLokasi);
        m.put("checkInTimestamp", checkInTimestamp); m.put("checkOutTimestamp", checkOutTimestamp);
        m.put("jamLembur", jamLembur); m.put("createdAt", createdAt != 0 ? createdAt : System.currentTimeMillis());
        return m;
    }

    public static Schedule fromMap(String id, Map<String, Object> m) {
        Schedule s = new Schedule();
        s.id = id; s.userId = (String) m.get("userId"); s.userName = (String) m.get("userName");
        s.shiftId = (String) m.get("shiftId"); s.shiftNama = (String) m.get("shiftNama");
        s.tanggal = (String) m.get("tanggal"); s.status = (String) m.get("status");
        s.checkInTime = (String) m.get("checkInTime"); s.checkOutTime = (String) m.get("checkOutTime");
        s.checkInFoto = (String) m.get("checkInFoto"); s.checkOutFoto = (String) m.get("checkOutFoto");
        s.checkInLokasi = (String) m.get("checkInLokasi"); s.checkOutLokasi = (String) m.get("checkOutLokasi");
        if (m.containsKey("checkInTimestamp")) s.checkInTimestamp = (Long) m.get("checkInTimestamp");
        if (m.containsKey("checkOutTimestamp")) s.checkOutTimestamp = (Long) m.get("checkOutTimestamp");
        if (m.containsKey("jamLembur")) s.jamLembur = m.get("jamLembur") instanceof Double ?
            (Double) m.get("jamLembur") : ((Long) m.get("jamLembur")).doubleValue();
        if (m.containsKey("createdAt")) s.createdAt = (Long) m.get("createdAt");
        return s;
    }
}
