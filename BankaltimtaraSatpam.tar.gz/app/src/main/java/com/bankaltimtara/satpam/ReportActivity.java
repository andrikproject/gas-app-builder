package com.bankaltimtara.satpam;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankaltimtara.satpam.models.Attendance;
import com.bankaltimtara.satpam.models.Overtime;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.DateUtils;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReportActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView tvEmpty, tvTotalHadir, tvTotalTerlambat, tvTotalLembur;
    private TabLayout tabLayout;

    private FirebaseService firebaseService;
    private PreferencesManager preferencesManager;
    private String userId;

    private List<Attendance> attendanceList;
    private List<Overtime> overtimeList;
    private ReportAdapter adapter;

    private int currentTab = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Laporan Saya");
        }

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTotalHadir = findViewById(R.id.tvTotalHadir);
        tvTotalTerlambat = findViewById(R.id.tvTotalTerlambat);
        tvTotalLembur = findViewById(R.id.tvTotalLembur);
        tabLayout = findViewById(R.id.tabLayout);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseService = FirebaseService.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        userId = preferencesManager.getUserId();

        attendanceList = new ArrayList<>();
        overtimeList = new ArrayList<>();
        adapter = new ReportAdapter(attendanceList);
        recyclerView.setAdapter(adapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                currentTab = tab.getPosition();
                if (currentTab == 0) {
                    adapter = new ReportAdapter(attendanceList);
                    recyclerView.setAdapter(adapter);
                    tvEmpty.setText("Belum ada data absensi");
                } else {
                    adapter = new ReportAdapter(overtimeList);
                    recyclerView.setAdapter(adapter);
                    tvEmpty.setText("Belum ada data lembur");
                }
                updateView();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        loadData();
    }

    private void loadData() {
        showLoading(true);

        firebaseService.getAttendanceByUser(userId, new FirebaseService.FirebaseCallback<List<Attendance>>() {
            @Override
            public void onSuccess(List<Attendance> attendances) {
                runOnUiThread(() -> {
                    attendanceList.clear();
                    if (attendances != null) {
                        Collections.sort(attendances, (a, b) -> {
                            if (a.tanggal == null) return 1;
                            if (b.tanggal == null) return -1;
                            return b.tanggal.compareTo(a.tanggal);
                        });
                        attendanceList.addAll(attendances);

                        int hadir = 0, terlambat = 0;
                        for (Attendance a : attendances) {
                            String s = a.status != null ? a.status : "";
                            if (s.equals("hadir")) hadir++;
                            else if (s.equals("terlambat")) terlambat++;
                        }
                        tvTotalHadir.setText(String.valueOf(hadir));
                        tvTotalTerlambat.setText(String.valueOf(terlambat));
                    }
                    updateView();
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat absensi: " + errorMessage, Snackbar.LENGTH_LONG).show();
                    updateView();
                });
            }
        });

        firebaseService.getOvertimeByUser(userId, new FirebaseService.FirebaseCallback<List<Overtime>>() {
            @Override
            public void onSuccess(List<Overtime> overtimes) {
                runOnUiThread(() -> {
                    overtimeList.clear();
                    if (overtimes != null) {
                        Collections.sort(overtimes, (a, b) -> {
                            if (a.tanggal == null) return 1;
                            if (b.tanggal == null) return -1;
                            return b.tanggal.compareTo(a.tanggal);
                        });
                        overtimeList.addAll(overtimes);

                        double totalLembur = 0;
                        for (Overtime o : overtimes) {
                            if ("disetujui".equals(o.status) || o.status == null) {
                                totalLembur += o.durasiJam;
                            }
                        }
                        tvTotalLembur.setText(String.format(Locale.getDefault(), "%.1f jam", totalLembur));
                    }
                    showLoading(false);
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat lembur: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void updateView() {
        showLoading(false);
        if (currentTab == 0) {
            if (attendanceList.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
                tvEmpty.setVisibility(View.VISIBLE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                tvEmpty.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            }
        } else {
            if (overtimeList.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
                tvEmpty.setVisibility(View.VISIBLE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                tvEmpty.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            }
        }
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Adapter untuk menampilkan absensi dan lembur
    static class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ViewHolder> {
        private final List<?> items;

        ReportAdapter(List<?> items) {
            this.items = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_report, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Object item = items.get(position);
            if (item instanceof Attendance) {
                Attendance a = (Attendance) item;
                holder.tvJudul.setText(a.tanggal + " - " + (a.shift != null ? a.shift : "-"));
                String status = a.status != null ? a.status : "-";
                holder.tvStatus.setText("Status: " + status + " " + a.getStatusIcon());
                holder.tvDetail.setText("Masuk: " + (a.checkInTime != null ? a.checkInTime : "-")
                        + " | Keluar: " + (a.checkOutTime != null ? a.checkOutTime : "-"));
            } else if (item instanceof Overtime) {
                Overtime o = (Overtime) item;
                holder.tvJudul.setText("Lembur - " + (o.tanggal != null ? o.tanggal : "-"));
                String status = o.status != null ? o.status : "pending";
                holder.tvStatus.setText("Status: " + status);
                holder.tvDetail.setText(String.format(Locale.getDefault(),
                        "Durasi: %.1f jam | Total: Rp %.0f", o.durasiJam, o.totalBayaran));
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvJudul, tvStatus, tvDetail;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvJudul = itemView.findViewById(R.id.tvJudul);
                tvStatus = itemView.findViewById(R.id.tvStatus);
                tvDetail = itemView.findViewById(R.id.tvDetail);
            }
        }
    }
}
