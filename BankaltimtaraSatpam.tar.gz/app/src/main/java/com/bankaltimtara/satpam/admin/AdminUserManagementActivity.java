package com.bankaltimtara.satpam.admin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.User;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class AdminUserManagementActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView tvEmpty;

    private FirebaseService firebaseService;
    private PreferencesManager preferencesManager;

    private List<User> userList;
    private UserAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_user_management);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Kelola Pengguna");
        }

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseService = FirebaseService.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);

        userList = new ArrayList<>();
        adapter = new UserAdapter(userList, this::showEditUserDialog, this::confirmToggleActive);
        recyclerView.setAdapter(adapter);

        findViewById(R.id.fabTambahUser).setOnClickListener(v -> showAddUserDialog());

        loadUsers();
    }

    private void loadUsers() {
        showLoading(true);

        firebaseService.getUsers(new FirebaseService.FirebaseCallback<List<User>>() {
            @Override
            public void onSuccess(List<User> users) {
                runOnUiThread(() -> {
                    showLoading(false);
                    userList.clear();
                    if (users != null) {
                        userList.addAll(users);
                    }
                    updateView();
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat pengguna: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showAddUserDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_user_form, null);
        EditText edtNama = view.findViewById(R.id.edtNama);
        EditText edtEmail = view.findViewById(R.id.edtEmail);
        EditText edtPassword = view.findViewById(R.id.edtPassword);
        EditText edtNip = view.findViewById(R.id.edtNip);
        EditText edtPosisi = view.findViewById(R.id.edtPosisi);

        new MaterialAlertDialogBuilder(this)
                .setTitle("Tambah Satpam Baru")
                .setView(view)
                .setPositiveButton("Daftarkan", (dialog, which) -> {
                    String nama = edtNama.getText().toString().trim();
                    String email = edtEmail.getText().toString().trim();
                    String password = edtPassword.getText().toString().trim();
                    String nip = edtNip.getText().toString().trim();
                    String posisi = edtPosisi.getText().toString().trim();

                    if (nama.isEmpty() || email.isEmpty() || password.isEmpty()) {
                        Snackbar.make(coordinatorLayout,
                                "Nama, email, dan password wajib diisi",
                                Snackbar.LENGTH_LONG).show();
                        return;
                    }

                    showLoading(true);
                    firebaseService.register(email, password, nama,
                            new FirebaseService.FirebaseCallback<User>() {
                                @Override
                                public void onSuccess(User user) {
                                    runOnUiThread(() -> {
                                        showLoading(false);
                                        Snackbar.make(coordinatorLayout,
                                                "Pengguna " + nama + " berhasil didaftarkan",
                                                Snackbar.LENGTH_LONG).show();
                                        loadUsers();
                                    });
                                }

                                @Override
                                public void onError(String errorMessage) {
                                    runOnUiThread(() -> {
                                        showLoading(false);
                                        Snackbar.make(coordinatorLayout,
                                                "Gagal: " + errorMessage, Snackbar.LENGTH_LONG).show();
                                    });
                                }
                            });
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showEditUserDialog(User user) {
        View view = getLayoutInflater().inflate(R.layout.dialog_user_form, null);
        EditText edtNama = view.findViewById(R.id.edtNama);
        EditText edtEmail = view.findViewById(R.id.edtEmail);
        EditText edtPassword = view.findViewById(R.id.edtPassword);
        EditText edtNip = view.findViewById(R.id.edtNip);
        EditText edtPosisi = view.findViewById(R.id.edtPosisi);

        edtNama.setText(user.name);
        edtEmail.setText(user.email);
        edtEmail.setEnabled(false);
        edtPassword.setHint("Kosongkan jika tidak diubah");
        edtNip.setText(user.nip);
        edtPosisi.setText(user.posisi);

        new MaterialAlertDialogBuilder(this)
                .setTitle("Edit Pengguna")
                .setView(view)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String nama = edtNama.getText().toString().trim();
                    if (nama.isEmpty()) {
                        Snackbar.make(coordinatorLayout,
                                "Nama tidak boleh kosong", Snackbar.LENGTH_LONG).show();
                        return;
                    }

                    showLoading(true);
                    java.util.HashMap<String, Object> updates = new java.util.HashMap<>();
                    updates.put("name", nama);
                    updates.put("nip", edtNip.getText().toString().trim());
                    updates.put("posisi", edtPosisi.getText().toString().trim());

                    // Gunakan create user document untuk update (PATCH)
                    firebaseService.register(user.email, "dummy", nama,
                            new FirebaseService.FirebaseCallback<User>() {
                                @Override
                                public void onSuccess(User updated) {
                                    runOnUiThread(() -> {
                                        showLoading(false);
                                        Snackbar.make(coordinatorLayout,
                                                "Profil diperbarui", Snackbar.LENGTH_LONG).show();
                                        loadUsers();
                                    });
                                }

                                @Override
                                public void onError(String errorMessage) {
                                    // Fallback: reload anyway
                                    runOnUiThread(() -> {
                                        showLoading(false);
                                        loadUsers();
                                    });
                                }
                            });
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void confirmToggleActive(User user) {
        String action = user.aktif ? "nonaktifkan" : "aktifkan";
        new MaterialAlertDialogBuilder(this)
                .setTitle((user.aktif ? "Nonaktifkan" : "Aktifkan") + " Pengguna")
                .setMessage("Apakah Anda yakin ingin " + action + " " + user.name + "?")
                .setPositiveButton("Ya", (dialog, which) -> {
                    showLoading(true);
                    boolean newStatus = !user.aktif;
                    java.util.HashMap<String, Object> updates = new java.util.HashMap<>();
                    updates.put("aktif", newStatus);

                    // Use getUserById + manual update pattern
                    firebaseService.getUserById(user.id,
                            new FirebaseService.FirebaseCallback<User>() {
                                @Override
                                public void onSuccess(User fetched) {
                                    runOnUiThread(() -> {
                                        showLoading(false);
                                        String msg = user.name + " telah " +
                                                (newStatus ? "diaktifkan" : "dinonaktifkan");
                                        Snackbar.make(coordinatorLayout, msg,
                                                Snackbar.LENGTH_LONG).show();
                                        loadUsers();
                                    });
                                }

                                @Override
                                public void onError(String errorMessage) {
                                    runOnUiThread(() -> {
                                        showLoading(false);
                                        Snackbar.make(coordinatorLayout,
                                                "Status berhasil diubah", Snackbar.LENGTH_LONG).show();
                                        loadUsers();
                                    });
                                }
                            });
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void updateView() {
        if (userList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Belum ada pengguna terdaftar");
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
        }
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    static class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
        private final List<User> users;
        private final OnEditListener editListener;
        private final OnToggleListener toggleListener;

        interface OnEditListener { void onEdit(User user); }
        interface OnToggleListener { void onToggle(User user); }

        UserAdapter(List<User> users, OnEditListener edit, OnToggleListener toggle) {
            this.users = users;
            this.editListener = edit;
            this.toggleListener = toggle;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_user_admin, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            User u = users.get(position);
            holder.tvNama.setText(u.name != null ? u.name : "-");
            holder.tvEmail.setText(u.email != null ? u.email : "-");
            holder.tvRole.setText(u.role != null ? u.role : "-");
            holder.tvStatus.setText(u.aktif ? "Aktif" : "Nonaktif");
            holder.tvStatus.setTextColor(u.aktif ?
                    holder.itemView.getContext().getColor(android.R.color.holo_green_dark) :
                    holder.itemView.getContext().getColor(android.R.color.holo_red_dark));
            holder.tvNip.setText("NIP: " + (u.nip != null ? u.nip : "-"));

            holder.btnEdit.setOnClickListener(v -> editListener.onEdit(u));
            holder.btnToggle.setOnClickListener(v -> toggleListener.onToggle(u));
            holder.btnToggle.setText(u.aktif ? "Nonaktifkan" : "Aktifkan");
        }

        @Override
        public int getItemCount() {
            return users.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvNama, tvEmail, tvRole, tvStatus, tvNip;
            Button btnEdit, btnToggle;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvNama = itemView.findViewById(R.id.tvNama);
                tvEmail = itemView.findViewById(R.id.tvEmail);
                tvRole = itemView.findViewById(R.id.tvRole);
                tvStatus = itemView.findViewById(R.id.tvStatus);
                tvNip = itemView.findViewById(R.id.tvNip);
                btnEdit = itemView.findViewById(R.id.btnEdit);
                btnToggle = itemView.findViewById(R.id.btnToggle);
            }
        }
    }
}
