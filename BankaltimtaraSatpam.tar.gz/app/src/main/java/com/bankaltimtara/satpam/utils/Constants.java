package com.bankaltimtara.satpam.utils;

public class Constants {
    // Firebase Config - GANTI dengan project kamu!
    public static final String FIREBASE_API_KEY = "AIzaSyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    public static final String FIREBASE_PROJECT_ID = "bankaltimtara-satpam";
    public static final String FIREBASE_DB_URL = "https://" + FIREBASE_PROJECT_ID + ".firebaseio.com";
    public static final String FCM_SERVER_KEY = ""; // Dari Firebase Console > Cloud Messaging

    // Shared Preferences
    public static final String PREFS_NAME = "BankaltimPrefs";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_USER_ROLE = "user_role";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_USER_NIP = "user_nip";
    public static final String KEY_FCM_TOKEN = "fcm_token";
    public static final String KEY_IS_LOGIN = "is_login";
    public static final String KEY_SHIFT_DURASI = "shift_durasi"; // "8" atau "12"

    // Collection Firestore
    public static final String COLLECTION_USERS = "users";
    public static final String COLLECTION_SHIFTS = "shifts";
    public static final String COLLECTION_SCHEDULES = "schedules";
    public static final String COLLECTION_ATTENDANCE = "attendance";
    public static final String COLLECTION_OVERTIME = "overtime";
    public static final String COLLECTION_NOTIFICATIONS = "notifications";
    public static final String COLLECTION_PERUSAHAAN = "perusahaan";

    // Notifikasi
    public static final String NOTIF_CHANNEL_ID = "satpam_channel";
    public static final String NOTIF_CHANNEL_NAME = "Jadwal Satpam";

    // Default shift times
    public static final String[][] SHIFT_8JAM = {
        {"Pagi", "06:00", "14:00"},
        {"Siang", "14:00", "22:00"},
        {"Malam", "22:00", "06:00"}
    };
    public static final String[][] SHIFT_12JAM = {
        {"Reguler 12 Jam", "07:00", "19:00"},
        {"Malam 12 Jam", "19:00", "07:00"}
    };

    // API Endpoints Firebase REST
    public static String getFirestoreApi(String collection) {
        return "https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID +
               "/databases/(default)/documents/" + collection +
               "?key=" + FIREBASE_API_KEY;
    }

    public static String getFirestoreDocApi(String collection, String docId) {
        return "https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID +
               "/databases/(default)/documents/" + collection + "/" + docId +
               "?key=" + FIREBASE_API_KEY;
    }

    public static String getFcmApi() {
        return "https://fcm.googleapis.com/fcm/send";
    }
}
