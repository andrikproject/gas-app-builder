package com.bankaltimtara.satpam.services;

import com.bankaltimtara.satpam.models.*;
import com.bankaltimtara.satpam.utils.DateUtils;

import java.util.*;

/**
 * Automatic work schedule generator for security guards (Satpam).
 * <p>
 * Produces a List of Schedule objects ready to save to Firestore, with fair
 * rotation, minimum rest enforcement, day-off guarantees, and overlap
 * detection against existing schedules.
 */
public class ScheduleGenerator {

    /** Minimum rest period in hours between the end of one shift and the start of the next. */
    private static final int MIN_REST_HOURS = 8;

    /** Shift end hour considered "late" — guards working past this time need extra rest. */
    private static final int LATE_HOUR_THRESHOLD = 22;

    /** Maximum consecutive work days before a mandatory day off is assigned. */
    private static final int MAX_CONSECUTIVE_WORK_DAYS = 6;

    /** Days in a scheduling week. */
    private static final int DAYS_PER_WEEK = 7;

    /** Minimum day-off slots per week every guard must receive. */
    private static final int MIN_DAYS_OFF_PER_WEEK = 1;

    // ─────────────────────────────────────────────────────────
    //  Public API
    // ─────────────────────────────────────────────────────────

    /**
     * Generate a complete schedule for the given date range.
     *
     * @param startDate first date of the range (yyyy-MM-dd)
     * @param endDate   last date of the range (yyyy-MM-dd)
     * @param guards    list of available active guards
     * @param shifts    list of shift configurations to fill each day
     * @return list of Schedule objects, ready to be persisted
     */
    public List<Schedule> generate(String startDate, String endDate,
                                    List<User> guards, List<Shift> shifts) {
        return generate(startDate, endDate, guards, shifts, new ArrayList<>());
    }

    /**
     * Generate a schedule while respecting existing assignments (overlap handling).
     * <p>
     * Existing schedules are loaded into guard tracking state so the generator
     * will not double-assign a guard on an already-occupied date, and will
     * respect rest/rotation constraints based on their prior shifts.
     *
     * @param startDate         first date of the range (yyyy-MM-dd)
     * @param endDate           last date of the range (yyyy-MM-dd)
     * @param guards            list of available active guards
     * @param shifts            list of shift configurations to fill each day
     * @param existingSchedules previously-saved schedules in the date range
     * @return list of Schedule objects (new assignments only; existing ones are
     *         not duplicated)
     */
    public List<Schedule> generate(String startDate, String endDate,
                                    List<User> guards, List<Shift> shifts,
                                    List<Schedule> existingSchedules) {
        List<Schedule> result = new ArrayList<>();
        if (guards == null || guards.isEmpty() || shifts == null || shifts.isEmpty()) {
            return result;
        }

        // Only active guards
        List<User> activeGuards = new ArrayList<>();
        for (User u : guards) {
            if (u.aktif && u.id != null) {
                activeGuards.add(u);
            }
        }
        if (activeGuards.isEmpty()) return result;

        // Sort shifts by start time so the earliest shift is assigned first
        List<Shift> sortedShifts = new ArrayList<>(shifts);
        sortedShifts.sort(Comparator.comparing(s -> s.jamMulai != null ? s.jamMulai : "00:00"));

        // Build a lookup for quick shift-by-id access (for existing schedule linking)
        Map<String, Shift> shiftLookup = new HashMap<>();
        for (Shift s : shifts) {
            if (s.id != null) {
                shiftLookup.put(s.id, s);
            }
        }

        // ── 1. Initialise per-guard state ────────────────────────
        Map<String, GuardState> guardStates = new LinkedHashMap<>();
        for (User u : activeGuards) {
            guardStates.put(u.id, new GuardState(u));
        }

        // ── 2. Load existing schedules into guard states ─────────
        //     This prevents duplicate assignments and respects rotation.
        for (Schedule s : existingSchedules) {
            if (s.userId == null || s.tanggal == null) continue;
            GuardState gs = guardStates.get(s.userId);
            if (gs == null) continue;

            // Resolve shift start/end times from the Shift model if possible,
            // otherwise fall back to checkInTime/checkOutTime on the Schedule.
            Shift shiftDef = shiftLookup.get(s.shiftId);
            String startTime = null;
            String endTime = null;
            if (shiftDef != null) {
                startTime = shiftDef.jamMulai;
                endTime = shiftDef.jamSelesai;
            }
            if (startTime == null) startTime = s.checkInTime;
            if (endTime == null) endTime = s.checkOutTime;
            boolean isWeekend = DateUtils.isAkhirPekan(s.tanggal);

            gs.addExistingAssignment(s.tanggal, s.shiftId, startTime, endTime, isWeekend);
        }

        // ── 3. Build the list of dates to process ────────────────
        List<String> dateList = new ArrayList<>();
        String cursor = startDate;
        while (cursor != null && cursor.compareTo(endDate) <= 0) {
            dateList.add(cursor);
            cursor = DateUtils.tambahHari(cursor, 1);
        }

        // ── 4. Day-by-day generation ─────────────────────────────
        for (String date : dateList) {
            boolean isWeekend = DateUtils.isAkhirPekan(date);

            // 4a. Assign each shift to the best available guard
            for (Shift shift : sortedShifts) {
                // Skip if every guard already has an assignment on this date
                // (the findBestGuard method handles individual availability).
                User chosen = findBestGuard(activeGuards, guardStates, date, shift, isWeekend);
                if (chosen == null) {
                    continue; // no suitable candidate; shift goes unfilled (rare edge case)
                }

                Schedule entry = buildScheduleEntry(chosen, shift, date);
                result.add(entry);

                GuardState gs = guardStates.get(chosen.id);
                gs.addAssignment(date, shift.id, shift.jamMulai, shift.jamSelesai, isWeekend);
            }

            // 4b. Assign mandatory day-off (libur) for guards who need one
            assignDayOffEntries(activeGuards, guardStates, date, result);
        }

        return result;
    }

    // ─────────────────────────────────────────────────────────
    //  Guard selection logic
    // ─────────────────────────────────────────────────────────

    /**
     * Score a guard for a given shift opportunity. Lower scores are better.
     * <p>
     * Factors (weight):
     * <ul>
     *   <li>Total shifts worked so far (×10)</li>
     *   <li>Weekend shifts worked (×20, only counted when assigning a weekend shift)</li>
     *   <li>Same-shift repetition penalty (+5 if last shift was the same type)</li>
     *   <li>Consecutive work days (heavily weighted after 5 days)</li>
     *   <li>Days-since-last-off bonus (−3 if &lt; 5, +5 otherwise)</li>
     * </ul>
     */
    private int scoreGuard(GuardState gs, Shift shift, boolean isWeekend) {
        int score = gs.totalShifts * 10;

        if (isWeekend) {
            score += gs.weekendShifts * 20;
        }

        // Slight rotation penalty for same shift type as last assignment
        if (gs.lastShiftId != null && gs.lastShiftId.equals(shift.id)) {
            score += 5;
        }

        // Days-since-last-off preference
        if (gs.daysSinceLastOff < 5) {
            score -= 3;               // recently rested — slightly prefers them
        } else {
            score += 5;               // hasn't had a break lately
        }

        // Heavy penalty for approaching the mandatory-day-off threshold
        if (gs.consecutiveWorkDays >= MAX_CONSECUTIVE_WORK_DAYS) {
            score += 150;             // must be given a day off
        } else if (gs.consecutiveWorkDays >= MAX_CONSECUTIVE_WORK_DAYS - 1) {
            score += 40;
        } else if (gs.consecutiveWorkDays >= MAX_CONSECUTIVE_WORK_DAYS - 2) {
            score += 10;
        }

        // Weekly shift-count fairness
        if (gs.totalShiftsThisWeek >= 5) {
            score += (gs.totalShiftsThisWeek - 4) * 15;
        }

        return score;
    }

    /**
     * Find the single best candidate guard for the given shift on {@code date}.
     * <p>
     * Three tiers of fallback are used:
     * <ol>
     *   <li>Guard has no assignment on {@code date}, meets rest &amp; consecutive-shift rules.</li>
     *   <li>Guard has no assignment but fails rest rule (emergency fallback).</li>
     *   <li>Any guard without an assignment on {@code date} (last resort).</li>
     * </ol>
     * Within each tier the lowest-scoring guard (via {@link #scoreGuard}) is chosen.
     */
    private User findBestGuard(List<User> activeGuards,
                                Map<String, GuardState> guardStates,
                                String date, Shift shift, boolean isWeekend) {
        // Tier 1 — all rules enforced
        List<User> candidates = new ArrayList<>();
        for (User u : activeGuards) {
            GuardState gs = guardStates.get(u.id);
            if (gs == null) continue;
            if (gs.hasAssignmentOnDate(date)) continue;
            if (!hasMinimumRest(gs, date, shift)) continue;
            if (wouldCauseConsecutiveShift(gs, date, shift)) continue;
            candidates.add(u);
        }

        // Tier 2 — relax rest requirement
        if (candidates.isEmpty()) {
            for (User u : activeGuards) {
                GuardState gs = guardStates.get(u.id);
                if (gs == null) continue;
                if (gs.hasAssignmentOnDate(date)) continue;
                if (wouldCauseConsecutiveShift(gs, date, shift)) continue;
                candidates.add(u);
            }
        }

        // Tier 3 — only check daily uniqueness
        if (candidates.isEmpty()) {
            for (User u : activeGuards) {
                GuardState gs = guardStates.get(u.id);
                if (gs == null) continue;
                if (gs.hasAssignmentOnDate(date)) continue;
                candidates.add(u);
            }
        }

        if (candidates.isEmpty()) return null;

        // Pick the lowest-scored candidate
        User best = null;
        int bestScore = Integer.MAX_VALUE;
        for (User u : candidates) {
            GuardState gs = guardStates.get(u.id);
            int s = scoreGuard(gs, shift, isWeekend);
            if (s < bestScore) {
                bestScore = s;
                best = u;
            }
        }
        return best;
    }

    // ─────────────────────────────────────────────────────────
    //  Rest & consecutive-shift rules
    // ─────────────────────────────────────────────────────────

    /**
     * Check that the guard has had at least {@link #MIN_REST_HOURS} hours of rest
     * between their last assignment and the given shift on {@code date}.
     * <p>
     * Special handling for overnight shifts (e.g. Malam 22:00‑06:00) that end
     * after midnight — a guard who finishes at 06:00 cannot start Pagi 06:00
     * on the same day because there is zero rest.
     */
    private boolean hasMinimumRest(GuardState gs, String date, Shift shift) {
        if (gs.lastAssignmentDate == null || gs.lastShiftEndTime == null) {
            return true;
        }

        // If the last assignment was on a strictly earlier date, it's always fine
        // (the rest gap spans at least a full day).
        if (gs.lastAssignmentDate.compareTo(date) < 0) {
            // Check if the previous day's shift was overnight and this one starts early
            String prevDate = DateUtils.tambahHari(date, -1);
            if (!gs.lastAssignmentDate.equals(prevDate)) {
                return true; // last assignment was more than one day ago
            }

            try {
                int lastEnd = hourFromTime(gs.lastShiftEndTime);
                int start = hourFromTime(shift.jamMulai);

                // Overnight shift ending in the morning (e.g. Malam 22:00→06:00)
                // followed by an early shift the same calendar day.
                if (lastEnd >= LATE_HOUR_THRESHOLD) {
                    // The shift ends at e.g. 06:00 the next calendar day.
                    // Effective rest = start hour (because the guard finishes at 'lastEnd'
                    // on the PREVIOUS calendar date, but the shift actually runs into today).
                    // We compute hours between effective end (lastEndh - 24) and start.
                    // Simplified: if lastEnd >= 22, it means the shift runs overnight,
                    // ending at e.g. 06:00. So the actual end time the next morning is
                    // 'lastEnd - 24' hours from midnight, i.e. the actual hour of day.
                    int effectiveEndHour = lastEnd >= 24 ? lastEnd - 24 : lastEnd;
                    // For Malam 22:00-06:00, lastEnd is stored as 6 (hour of jamSelesai)
                    // Actually, looking at Shift model: jamSelesai for Malam is "06:00"
                    // So lastEnd = 6, which is < 22. That means it's a morning time.
                    // The overnight detection should instead use jamMulai of the last shift.
                    // Let me look at the last shift's start time.
                    String lastStart = gs.lastShiftStartTime;
                    int lastStartHour = lastStart != null ? hourFromTime(lastStart) : 0;

                    // If the last shift started in the evening (>= LATE_HOUR_THRESHOLD)
                    // and ended in the morning (< LATE_HOUR_THRESHOLD), it's overnight.
                    if (lastStartHour >= LATE_HOUR_THRESHOLD && lastEnd < LATE_HOUR_THRESHOLD) {
                        // Overnight shift: effectively ends at 'lastEnd' in the morning of 'date'
                        // Current shift starts at 'start'. Gap = start - lastEnd.
                        int gap = start - lastEnd;
                        if (gap < MIN_REST_HOURS) {
                            return false;
                        }
                    }
                }

                // General gap check for same-day adjacent shifts
                if (start <= lastEnd) {
                    // This shouldn't happen for different calendar days, but just in case
                    return true;
                }
                int gap = start - lastEnd;
                return gap >= MIN_REST_HOURS;

            } catch (Exception e) {
                return true; // parsing failure — be permissive
            }
        }

        // Not reached for typical flow
        return true;
    }

    /**
     * Returns true if assigning this shift would violate the "no consecutive shifts"
     * rule. A shift is considered consecutive if the guard's last shift ended
     * less than {@link #MIN_REST_HOURS} hours before this one starts.
     * <p>
     * This overlaps somewhat with {@link #hasMinimumRest} but is checked separately
     * to provide an explicit hard block vs. a scoring preference.
     */
    private boolean wouldCauseConsecutiveShift(GuardState gs, String date, Shift shift) {
        if (gs.lastAssignmentDate == null || gs.lastShiftEndTime == null) {
            return false;
        }

        String prevDate = DateUtils.tambahHari(date, -1);
        if (!gs.lastAssignmentDate.equals(prevDate)) {
            return false; // only matters for consecutive calendar days
        }

        try {
            int lastEndHour = hourFromTime(gs.lastShiftEndTime);
            int currentStartHour = hourFromTime(shift.jamMulai);

            // Determine if last shift was an overnight shift (started late, ended early morning)
            String lastStartTime = gs.lastShiftStartTime;
            boolean wasOvernight = false;
            if (lastStartTime != null) {
                int lastStartHour = hourFromTime(lastStartTime);
                wasOvernight = lastStartHour >= LATE_HOUR_THRESHOLD && lastEndHour < LATE_HOUR_THRESHOLD;
            }

            int gap;
            if (wasOvernight) {
                // Overnight shift ends at 'lastEndHour' in the morning of 'date'.
                // The current shift starts at 'currentStartHour' on the SAME day.
                gap = currentStartHour - lastEndHour;
            } else if (lastEndHour >= LATE_HOUR_THRESHOLD && currentStartHour < LATE_HOUR_THRESHOLD) {
                // Late-ending shift (e.g., Siang ends 22:00) followed by early morning shift
                gap = (24 - lastEndHour) + currentStartHour;
            } else {
                gap = currentStartHour - lastEndHour;
            }

            return gap < MIN_REST_HOURS;

        } catch (Exception e) {
            return false;
        }
    }

    // ─────────────────────────────────────────────────────────
    //  Day-off (libur) assignment
    // ─────────────────────────────────────────────────────────

    /**
     * Assign &#39;libur&#39; Schedule entries to guards who have not yet been assigned a shift
     * on {@code date} and meet any of the following criteria:
     * <ul>
     *   <li>Consecutive work days >= {@link #MAX_CONSECUTIVE_WORK_DAYS}</li>
     *   <li>Worked 6+ days this week without any day off</li>
     * </ul>
     * <p>
     * This method also resets the consecutive-work counter for guards receiving a
     * day off and updates their weekly tracking.
     */
    private void assignDayOffEntries(List<User> activeGuards,
                                      Map<String, GuardState> guardStates,
                                      String date, List<Schedule> result) {
        // Collect guards who have no assignment on this date
        List<GuardState> unassigned = new ArrayList<>();
        for (User u : activeGuards) {
            GuardState gs = guardStates.get(u.id);
            if (gs == null) continue;
            if (!gs.hasAssignmentOnDate(date)) {
                unassigned.add(gs);
            }
        }

        for (GuardState gs : unassigned) {
            boolean needsDayOff = false;

            // Mandatory day off after MAX_CONSECUTIVE_WORK_DAYS
            if (gs.consecutiveWorkDays >= MAX_CONSECUTIVE_WORK_DAYS) {
                needsDayOff = true;
            }

            // Weekly day-off guarantee
            if (gs.daysSinceLastOff >= DAYS_PER_WEEK) {
                needsDayOff = true;
            }

            // Fairness: ensure at least MIN_DAYS_OFF_PER_WEEK per 7-day window
            // by tracking total shifts this week
            if (!needsDayOff && gs.totalShiftsThisWeek >= (DAYS_PER_WEEK - MIN_DAYS_OFF_PER_WEEK)) {
                // Count how many days this week the guard has already been off
                int offDaysThisWeek = gs.daysSinceLastOff == 0 ? 1 : 0;
                // Simplified heuristic — if they've worked 6+ days, give them a break
                if (gs.totalShiftsThisWeek >= 6) {
                    needsDayOff = true;
                }
            }

            if (needsDayOff) {
                Schedule libur = new Schedule();
                libur.userId = gs.user.id;
                libur.userName = gs.user.name;
                libur.tanggal = date;
                libur.status = "libur";
                libur.createdAt = System.currentTimeMillis();
                result.add(libur);

                gs.addDayOff(date);
            }
        }
    }

    // ─────────────────────────────────────────────────────────
    //  Schedule POJO builder
    // ─────────────────────────────────────────────────────────

    /**
     * Build a single Schedule entry from a guard, shift, and date.
     */
    private Schedule buildScheduleEntry(User guard, Shift shift, String date) {
        Schedule s = new Schedule();
        s.userId = guard.id;
        s.userName = guard.name;
        s.shiftId = shift.id;
        s.shiftNama = shift.nama;
        s.tanggal = date;
        s.checkInTime = shift.jamMulai;
        s.checkOutTime = shift.jamSelesai;
        s.status = "terjadwal";
        s.createdAt = System.currentTimeMillis();
        return s;
    }

    // ─────────────────────────────────────────────────────────
    //  Internal helpers
    // ─────────────────────────────────────────────────────────

    /**
     * Parse the hour component from a time string in HH:mm format.
     */
    private static int hourFromTime(String time) {
        if (time == null || !time.contains(":")) return 0;
        return Integer.parseInt(time.split(":")[0]);
    }

    // ─────────────────────────────────────────────────────────
    //  Per-guard state tracker
    // ─────────────────────────────────────────────────────────

    /**
     * Mutable state object that tracks a single guard's assignment history
     * across the generation run.
     */
    private static class GuardState {
        final User user;

        String lastShiftId;
        String lastAssignmentDate;
        String lastShiftStartTime;
        String lastShiftEndTime;

        int totalShifts;
        int weekendShifts;
        int consecutiveWorkDays;
        int daysSinceLastOff;
        int totalShiftsThisWeek;

        /** Set of dates (yyyy-MM-dd) on which this guard has any assignment or day-off. */
        final Set<String> assignedDates = new HashSet<>();

        GuardState(User user) {
            this.user = user;
            this.daysSinceLastOff = DAYS_PER_WEEK; // bootstrap — not immediately due for a day off
        }

        boolean hasAssignmentOnDate(String date) {
            return assignedDates.contains(date);
        }

        void addAssignment(String date, String shiftId,
                           String startTime, String endTime,
                           boolean isWeekend) {
            recordAssignment(date, shiftId, startTime, endTime, isWeekend);
        }

        void addExistingAssignment(String date, String shiftId,
                                    String startTime, String endTime,
                                    boolean isWeekend) {
            recordAssignment(date, shiftId, startTime, endTime, isWeekend);
        }

        private void recordAssignment(String date, String shiftId,
                                       String startTime, String endTime,
                                       boolean isWeekend) {
            assignedDates.add(date);
            lastShiftId = shiftId;
            lastAssignmentDate = date;
            lastShiftStartTime = startTime;
            lastShiftEndTime = endTime;
            totalShifts++;
            totalShiftsThisWeek++;
            consecutiveWorkDays++;
            daysSinceLastOff++;
            if (isWeekend) {
                weekendShifts++;
            }
        }

        void addDayOff(String date) {
            assignedDates.add(date);
            consecutiveWorkDays = 0;
            daysSinceLastOff = 0;
            // A day off does not count as a shift, but it resets the counters.
            // We do NOT increment totalShifts or totalShiftsThisWeek.
        }
    }
}
