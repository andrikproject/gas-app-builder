package com.bankaltimtara.satpam;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bankaltimtara.satpam.models.Attendance;
import com.bankaltimtara.satpam.models.Schedule;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.DateUtils;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AttendanceActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST = 100;

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private TextView tvTanggal, tvShiftHariIni, tvStatusHariIni;
    private TextView tvJamMasuk, tvJamKeluar, tvLokasi;
    private Button btnCheckIn, btnCheckOut;

    private FirebaseService firebaseService;
    private PreferencesManager preferencesManager;
    private String userId, userName;

    private Schedule todaySchedule;
    private boolean hasCheckedIn = false;
    private double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Absensi");
        }

        progressBar = findViewById(R.id.progressBar);
        tvTanggal = findViewById(R.id.tvTanggal);
        tvShiftHariIni = findViewById(R.id.tvShiftHariIni);
        tvStatusHariIni = findViewById(R.id.tvStatusHariIni);
        tvJamMasuk = findViewById(R.id.tvJamMasuk);
        tvJamKeluar = findViewById(R.id.tvJamKeluar);
        tvLokasi = findViewById(R.id.tvLokasi);
        btnCheckIn = findViewById(R.id.btnCheckIn);
        btnCheckOut = findViewById(R.id.btnCheckOut);

        firebaseService = FirebaseService.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        userId = preferencesManager.getUserId();
        userName = preferencesManager.getUserName();

        tvTanggal.setText("Tanggal: " + DateUtils.formatTanggal(DateUtils.today()));

        btnCheckIn.setOnClickListener(v -> checkIn());
        btnCheckOut.setOnClickListener(v -> checkOut());

        cekLokasiPermission();
        loadTodaySchedule();
    }

    private void cekLokasiPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST);
        }
    }

    private void loadTodaySchedule() {
        showLoading(true);

        String today = DateUtils.today();
        firebaseService.getSchedulesByUser(userId, new FirebaseService.FirebaseCallback<List<Schedule>>() {
            @Override
            public void onSuccess(List<Schedule> schedules) {
                runOnUiThread(() -> {
                    showLoading(false);
                    todaySchedule = null;
                    for (Schedule s : schedules) {
                        if (s.tanggal != null && s.tanggal.equals(today)) {
                            todaySchedule = s;
                            break;
                        }
                    }

                    if (todaySchedule != null) {
                        tvShiftHariIni.setText("Shift: " +
                                (todaySchedule.shiftNama != null ? todaySchedule.shiftNama : "-"));
                        tvJamMasuk.setText("Jam Masuk: " +
                                (todaySchedule.checkInTime != null ? todaySchedule.checkInTime : "-"));
                        tvJamKeluar.setText("Jam Keluar: " +
                                (todaySchedule.checkOutTime != null ? todaySchedule.checkOutTime : "-"));

                        String status = todaySchedule.status;
                        if ("checkin".equals(status) || "checkout".equals(status)) {
                            hasCheckedIn = true;
                            tvStatusHariIni.setText("Status: Sudah Check In");
                            btnCheckIn.setEnabled(false);
                            btnCheckIn.setText("Sudah Check In");
                            if ("checkout".equals(status)) {
                                btnCheckOut.setEnabled(false);
                                btnCheckOut.setText("Sudah Check Out");
                            } else {
                                btnCheckOut.setEnabled(true);
                            }
                        } else if ("libur".equals(status)) {
                            tvStatusHariIni.setText("Status: Libur");
                            btnCheckIn.setEnabled(false);
                            btnCheckOut.setEnabled(false);
                        } else {
                            tvStatusHariIni.setText("Status: Belum Check In");
                            btnCheckIn.setEnabled(true);
                            btnCheckOut.setEnabled(false);
                        }
                    } else {
                        tvShiftHariIni.setText("Shift: Tidak ada jadwal hari ini");
                        tvJamMasuk.setText("Jam Masuk: -");
                        tvJamKeluar.setText("Jam Keluar: -");
                        tvStatusHariIni.setText("Status: Libur");
                        btnCheckIn.setEnabled(false);
                        btnCheckOut.setEnabled(false);
                    }
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat jadwal: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void checkIn() {
        if (todaySchedule == null) {
            Snackbar.make(coordinatorLayout, "Tidak ada jadwal hari ini", Snackbar.LENGTH_LONG).show();
            return;
        }

        showLoading(true);
        String now = DateUtils.nowTime();
        String today = DateUtils.today();

        Attendance attendance = new Attendance();
        attendance.userId = userId;
        attendance.userName = userName;
        attendance.tanggal = today;
        attendance.shift = todaySchedule.shiftNama;
        attendance.checkInTime = now;
        attendance.lokasiMasuk = latitude + "," + longitude;
        attendance.status = "hadir";

        firebaseService.createAttendance(attendance, new FirebaseService.FirebaseCallback<Attendance>() {
            @Override
            public void onSuccess(Attendance attendance) {
                // Update jadwal status jadi checkin
                java.util.HashMap<String, Object> updates = new java.util.HashMap<>();
                updates.put("status", "checkin");
                updates.put("checkInTime", now);
                firebaseService.updateSchedule(todaySchedule.id, updates,
                        new FirebaseService.FirebaseCallback<Schedule>() {
                            @Override
                            public void onSuccess(Schedule schedule) {
                                runOnUiThread(() -> {
                                    showLoading(false);
                                    hasCheckedIn = true;
                                    tvStatusHariIni.setText("Status: Sudah Check In");
                                    btnCheckIn.setEnabled(false);
                                    btnCheckIn.setText("Sudah Check In");
                                    btnCheckOut.setEnabled(true);
                                    Snackbar.make(coordinatorLayout,
                                            "Check In berhasil jam " + now, Snackbar.LENGTH_LONG).show();
                                });
                            }

                            @Override
                            public void onError(String errorMessage) {
                                runOnUiThread(() -> {
                                    showLoading(false);
                                    Snackbar.make(coordinatorLayout,
                                            "Check In berhasil, tetapi gagal update jadwal",
                                            Snackbar.LENGTH_LONG).show();
                                });
                            }
                        });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal Check In: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void checkOut() {
        if (todaySchedule == null || !hasCheckedIn) {
            Snackbar.make(coordinatorLayout, "Belum Check In", Snackbar.LENGTH_LONG).show();
            return;
        }

        showLoading(true);
        String now = DateUtils.nowTime();

        java.util.HashMap<String, Object> updates = new java.util.HashMap<>();
        updates.put("status", "checkout");
        updates.put("checkOutTime", now);
        updates.put("jamLembur", DateUtils.hitungJamLembur(
                todaySchedule.checkInTime, todaySchedule.checkOutTime,
                todaySchedule.checkInTime, now));

        firebaseService.updateSchedule(todaySchedule.id, updates,
                new FirebaseService.FirebaseCallback<Schedule>() {
                    @Override
                    public void onSuccess(Schedule schedule) {
                        runOnUiThread(() -> {
                            showLoading(false);
                            btnCheckOut.setEnabled(false);
                            btnCheckOut.setText("Sudah Check Out");
                            tvStatusHariIni.setText("Status: Selesai");
                            Snackbar.make(coordinatorLayout,
                                    "Check Out berhasil jam " + now, Snackbar.LENGTH_LONG).show();
                        });
                    }

                    @Override
                    public void onError(String errorMessage) {
                        runOnUiThread(() -> {
                            showLoading(false);
                            Snackbar.make(coordinatorLayout,
                                    "Gagal Check Out: " + errorMessage, Snackbar.LENGTH_LONG).show();
                        });
                    }
                });
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        btnCheckIn.setEnabled(!show);
        btnCheckOut.setEnabled(!show);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                tvLokasi.setText("Lokasi: Diizinkan");
            } else {
                tvLokasi.setText("Lokasi: Tidak diizinkan");
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
