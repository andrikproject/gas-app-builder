package com.bankaltimtara.satpam;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankaltimtara.satpam.models.Schedule;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.DateUtils;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ScheduleActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView tvEmpty;

    private FirebaseService firebaseService;
    private PreferencesManager preferencesManager;
    private String userId;
    private ScheduleAdapter adapter;
    private List<Schedule> scheduleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Jadwal Saya");
        }

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseService = FirebaseService.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        userId = preferencesManager.getUserId();

        scheduleList = new ArrayList<>();
        adapter = new ScheduleAdapter(scheduleList);
        recyclerView.setAdapter(adapter);

        loadSchedules();
    }

    private void loadSchedules() {
        showLoading(true);

        firebaseService.getSchedulesByUser(userId, new FirebaseService.FirebaseCallback<List<Schedule>>() {
            @Override
            public void onSuccess(List<Schedule> schedules) {
                runOnUiThread(() -> {
                    showLoading(false);
                    if (schedules != null && !schedules.isEmpty()) {
                        // Urutkan berdasarkan tanggal terbaru
                        Collections.sort(schedules, (a, b) -> {
                            if (a.tanggal == null) return 1;
                            if (b.tanggal == null) return -1;
                            return b.tanggal.compareTo(a.tanggal);
                        });
                        scheduleList.clear();
                        scheduleList.addAll(schedules);
                        adapter.notifyDataSetChanged();
                        recyclerView.setVisibility(View.VISIBLE);
                        tvEmpty.setVisibility(View.GONE);
                    } else {
                        recyclerView.setVisibility(View.GONE);
                        tvEmpty.setVisibility(View.VISIBLE);
                        tvEmpty.setText("Belum ada jadwal");
                    }
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    tvEmpty.setVisibility(View.VISIBLE);
                    tvEmpty.setText("Gagal memuat jadwal");
                    Snackbar.make(coordinatorLayout,
                            "Error: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // ViewHolder untuk jadwal
    static class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {
        private final List<Schedule> schedules;

        ScheduleAdapter(List<Schedule> schedules) {
            this.schedules = schedules;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_schedule, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Schedule s = schedules.get(position);
            holder.tvTanggal.setText(s.tanggal != null ? DateUtils.formatTanggal(s.tanggal) : "-");
            holder.tvShift.setText("Shift: " + (s.shiftNama != null ? s.shiftNama : "-"));

            String status = s.status != null ? s.status : "terjadwal";
            switch (status) {
                case "checkin":
                    holder.tvStatus.setText("Sudah Check In");
                    break;
                case "checkout":
                    holder.tvStatus.setText("Selesai");
                    break;
                case "libur":
                    holder.tvStatus.setText("Libur");
                    break;
                case "alpa":
                    holder.tvStatus.setText("Alpa");
                    break;
                case "cuti":
                    holder.tvStatus.setText("Cuti");
                    break;
                default:
                    holder.tvStatus.setText("Terjadwal");
                    break;
            }

            holder.tvJam.setText((s.checkInTime != null ? s.checkInTime : "-")
                    + " - " + (s.checkOutTime != null ? s.checkOutTime : "-"));
        }

        @Override
        public int getItemCount() {
            return schedules.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTanggal, tvShift, tvStatus, tvJam;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvTanggal = itemView.findViewById(R.id.tvTanggal);
                tvShift = itemView.findViewById(R.id.tvShift);
                tvStatus = itemView.findViewById(R.id.tvStatus);
                tvJam = itemView.findViewById(R.id.tvJam);
            }
        }
    }
}
