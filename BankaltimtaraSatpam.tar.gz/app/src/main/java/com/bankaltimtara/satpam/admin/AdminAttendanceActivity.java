package com.bankaltimtara.satpam.admin;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.Attendance;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AdminAttendanceActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView tvEmpty, tvTotalHadir, tvTotalTerlambat, tvTotalAlpa;

    private FirebaseService firebaseService;

    private List<Attendance> attendanceList;
    private AttendanceAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_attendance);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Semua Absensi");
        }

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTotalHadir = findViewById(R.id.tvTotalHadir);
        tvTotalTerlambat = findViewById(R.id.tvTotalTerlambat);
        tvTotalAlpa = findViewById(R.id.tvTotalAlpa);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseService = FirebaseService.getInstance(this);

        attendanceList = new ArrayList<>();
        adapter = new AttendanceAdapter(attendanceList);
        recyclerView.setAdapter(adapter);

        loadAttendance();
    }

    private void loadAttendance() {
        showLoading(true);

        firebaseService.getAttendance(new FirebaseService.FirebaseCallback<List<Attendance>>() {
            @Override
            public void onSuccess(List<Attendance> attendances) {
                runOnUiThread(() -> {
                    showLoading(false);

                    if (attendances != null) {
                        // Urutkan dari terbaru
                        Collections.sort(attendances, (a, b) -> {
                            if (a.tanggal == null) return 1;
                            if (b.tanggal == null) return -1;
                            return b.tanggal.compareTo(a.tanggal);
                        });

                        attendanceList.clear();
                        attendanceList.addAll(attendances);

                        // Hitung statistik
                        int hadir = 0, terlambat = 0, alpa = 0;
                        for (Attendance a : attendances) {
                            String s = a.status != null ? a.status : "";
                            switch (s) {
                                case "hadir": hadir++; break;
                                case "terlambat": terlambat++; break;
                                case "alpa": alpa++; break;
                            }
                        }
                        tvTotalHadir.setText(String.valueOf(hadir));
                        tvTotalTerlambat.setText(String.valueOf(terlambat));
                        tvTotalAlpa.setText(String.valueOf(alpa));
                    }

                    updateView();
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat absensi: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void updateView() {
        if (attendanceList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Belum ada data absensi");
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
        }
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    static class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder> {
        private final List<Attendance> attendances;

        AttendanceAdapter(List<Attendance> attendances) {
            this.attendances = attendances;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_attendance_admin, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Attendance a = attendances.get(position);
            holder.tvNama.setText(a.userName != null ? a.userName : "-");
            holder.tvTanggal.setText(a.tanggal != null ? a.tanggal : "-");
            holder.tvShift.setText(a.shift != null ? a.shift : "-");
            String status = a.status != null ? a.status : "-";
            holder.tvStatus.setText(status + " " + a.getStatusIcon());
            holder.tvJam.setText("Masuk: " + (a.checkInTime != null ? a.checkInTime : "-")
                    + " | Keluar: " + (a.checkOutTime != null ? a.checkOutTime : "-"));
        }

        @Override
        public int getItemCount() {
            return attendances.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvNama, tvTanggal, tvShift, tvStatus, tvJam;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvNama = itemView.findViewById(R.id.tvNamaUser);
                tvTanggal = itemView.findViewById(R.id.tvTanggal);
                tvShift = itemView.findViewById(R.id.tvShift);
                tvStatus = itemView.findViewById(R.id.tvStatus);
                tvJam = itemView.findViewById(R.id.tvJam);
            }
        }
    }
}
