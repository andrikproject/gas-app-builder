package com.bankaltimtara.satpam;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.bankaltimtara.satpam.models.User;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.PreferencesManager;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private TextInputLayout tilEmail, tilPassword;
    private EditText edtEmail, edtPassword;
    private Button btnLogin, btnRegister;
    private ProgressBar progressBar;
    private TextView tvJudul;

    private FirebaseService firebaseService;
    private PreferencesManager preferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        tilEmail = findViewById(R.id.tilEmail);
        tilPassword = findViewById(R.id.tilPassword);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        progressBar = findViewById(R.id.progressBar);
        tvJudul = findViewById(R.id.tvJudul);

        firebaseService = FirebaseService.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);

        // Cek jika sudah login
        if (preferencesManager.isLoggedIn()) {
            navigasiKeHalamanUtama();
            return;
        }

        btnLogin.setOnClickListener(v -> login());
        btnRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void login() {
        String email = edtEmail.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();

        // Validasi
        if (TextUtils.isEmpty(email)) {
            tilEmail.setError("Email tidak boleh kosong");
            return;
        }
        tilEmail.setError(null);

        if (TextUtils.isEmpty(password)) {
            tilPassword.setError("Password tidak boleh kosong");
            return;
        }
        tilPassword.setError(null);

        showLoading(true);

        firebaseService.login(email, password, new FirebaseService.FirebaseCallback<User>() {
            @Override
            public void onSuccess(User user) {
                runOnUiThread(() -> {
                    showLoading(false);
                    if (user != null) {
                        preferencesManager.saveUser(user);
                        Toast.makeText(LoginActivity.this,
                                "Selamat datang, " + user.name + "!",
                                Toast.LENGTH_SHORT).show();
                        navigasiKeHalamanUtama();
                    } else {
                        Snackbar.make(coordinatorLayout,
                                "Gagal mendapatkan data pengguna", Snackbar.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    String pesan = errorMessage;
                    if (pesan.contains("INVALID_LOGIN_CREDENTIALS")) {
                        pesan = "Email atau password salah";
                    } else if (pesan.contains("USER_DISABLED")) {
                        pesan = "Akun telah dinonaktifkan";
                    } else if (pesan.contains("EMAIL_NOT_FOUND")) {
                        pesan = "Email tidak terdaftar";
                    }
                    Snackbar.make(coordinatorLayout, "Login gagal: " + pesan,
                            Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void navigasiKeHalamanUtama() {
        String role = preferencesManager.getUserRole();
        Intent intent;
        if ("admin".equalsIgnoreCase(role)) {
            intent = new Intent(LoginActivity.this,
                    com.bankaltimtara.satpam.admin.AdminDashboardActivity.class);
        } else {
            intent = new Intent(LoginActivity.this, MainActivity.class);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!show);
        btnRegister.setEnabled(!show);
        edtEmail.setEnabled(!show);
        edtPassword.setEnabled(!show);
    }
}
