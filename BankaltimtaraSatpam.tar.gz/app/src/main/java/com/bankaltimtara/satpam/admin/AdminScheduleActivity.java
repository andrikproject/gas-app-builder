package com.bankaltimtara.satpam.admin;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.Schedule;
import com.bankaltimtara.satpam.models.Shift;
import com.bankaltimtara.satpam.models.User;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.services.ScheduleGenerator;
import com.bankaltimtara.satpam.utils.DateUtils;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class AdminScheduleActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView tvEmpty, tvRangeTanggal;
    private Button btnPilihTanggal, btnGenerate;

    private FirebaseService firebaseService;
    private ScheduleGenerator scheduleGenerator;

    private List<Schedule> scheduleList;
    private ScheduleAdapter adapter;

    private String startDate, endDate;
    private List<User> guards;
    private List<Shift> shifts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_schedule);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Kelola Jadwal");
        }

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvRangeTanggal = findViewById(R.id.tvRangeTanggal);
        btnPilihTanggal = findViewById(R.id.btnPilihTanggal);
        btnGenerate = findViewById(R.id.btnGenerate);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseService = FirebaseService.getInstance(this);
        scheduleGenerator = new ScheduleGenerator();

        scheduleList = new ArrayList<>();
        adapter = new ScheduleAdapter(scheduleList);
        recyclerView.setAdapter(adapter);

        // Default range: bulan ini
        Calendar cal = Calendar.getInstance();
        int tahun = cal.get(Calendar.YEAR);
        int bulan = cal.get(Calendar.MONTH) + 1;
        String[] range = DateUtils.getRangeBulan(tahun, bulan);
        startDate = range[0];
        endDate = range[1];
        tvRangeTanggal.setText(startDate + " s/d " + endDate);

        btnPilihTanggal.setOnClickListener(v -> showDateRangePicker());
        btnGenerate.setOnClickListener(v -> generateSchedule());

        loadSchedules();
    }

    private void showDateRangePicker() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePicker = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    Calendar startCal = Calendar.getInstance();
                    startCal.set(selectedYear, selectedMonth, selectedDay);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

                    // Show end date picker after start is selected
                    DatePickerDialog endPicker = new DatePickerDialog(this,
                            (view2, endYear, endMonth, endDay) -> {
                                Calendar endCal = Calendar.getInstance();
                                endCal.set(endYear, endMonth, endDay);
                                startDate = sdf.format(startCal.getTime());
                                endDate = sdf.format(endCal.getTime());
                                tvRangeTanggal.setText(startDate + " s/d " + endDate);
                                loadSchedules();
                            }, year, month, day + 7);
                    endPicker.getDatePicker().setMinDate(startCal.getTimeInMillis());
                    endPicker.show();
                }, year, month, day);
        datePicker.show();
    }

    private void loadSchedules() {
        showLoading(true);

        firebaseService.getSchedules(new FirebaseService.FirebaseCallback<List<Schedule>>() {
            @Override
            public void onSuccess(List<Schedule> schedules) {
                runOnUiThread(() -> {
                    showLoading(false);
                    scheduleList.clear();
                    if (schedules != null) {
                        for (Schedule s : schedules) {
                            if (s.tanggal != null && s.tanggal.compareTo(startDate) >= 0
                                    && s.tanggal.compareTo(endDate) <= 0) {
                                scheduleList.add(s);
                            }
                        }
                        Collections.sort(scheduleList, (a, b) -> {
                            if (a.tanggal == null) return 1;
                            if (b.tanggal == null) return -1;
                            int dateCmp = a.tanggal.compareTo(b.tanggal);
                            if (dateCmp != 0) return dateCmp;
                            if (a.userName == null) return 1;
                            if (b.userName == null) return -1;
                            return a.userName.compareTo(b.userName);
                        });
                    }
                    updateView();
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat jadwal: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void generateSchedule() {
        showLoading(true);

        // Load guards and shifts
        firebaseService.getUsers(new FirebaseService.FirebaseCallback<List<User>>() {
            @Override
            public void onSuccess(List<User> users) {
                guards = new ArrayList<>();
                if (users != null) {
                    for (User u : users) {
                        if ("satpam".equalsIgnoreCase(u.role) && u.aktif) {
                            guards.add(u);
                        }
                    }
                }
                loadShiftsAndGenerate();
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat pengguna: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void loadShiftsAndGenerate() {
        firebaseService.getShifts(new FirebaseService.FirebaseCallback<List<Shift>>() {
            @Override
            public void onSuccess(List<Shift> shifts) {
                AdminScheduleActivity.this.shifts = shifts;

                if (guards.isEmpty() || shifts.isEmpty()) {
                    runOnUiThread(() -> {
                        showLoading(false);
                        Snackbar.make(coordinatorLayout,
                                "Data satpam atau shift tidak tersedia", Snackbar.LENGTH_LONG).show();
                    });
                    return;
                }

                // Generate jadwal
                List<Schedule> generated = scheduleGenerator.generate(
                        startDate, endDate, guards, shifts);

                // Simpan ke Firebase
                saveGeneratedSchedules(generated, 0);
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Snackbar.make(coordinatorLayout,
                            "Gagal memuat shift: " + errorMessage, Snackbar.LENGTH_LONG).show();
                });
            }
        });
    }

    private void saveGeneratedSchedules(List<Schedule> generated, int index) {
        if (index >= generated.size()) {
            runOnUiThread(() -> {
                showLoading(false);
                Snackbar.make(coordinatorLayout,
                        "Jadwal berhasil dibuat: " + generated.size() + " entri",
                        Snackbar.LENGTH_LONG).show();
                loadSchedules();
            });
            return;
        }

        firebaseService.createSchedule(generated.get(index),
                new FirebaseService.FirebaseCallback<Schedule>() {
                    @Override
                    public void onSuccess(Schedule schedule) {
                        saveGeneratedSchedules(generated, index + 1);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        saveGeneratedSchedules(generated, index + 1);
                    }
                });
    }

    private void updateView() {
        if (scheduleList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
        }
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        btnGenerate.setEnabled(!show);
        btnPilihTanggal.setEnabled(!show);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Adapter untuk menampilkan jadwal
    static class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {
        private final List<Schedule> schedules;

        ScheduleAdapter(List<Schedule> schedules) {
            this.schedules = schedules;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_schedule_admin, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Schedule s = schedules.get(position);
            holder.tvTanggal.setText(s.tanggal != null ? s.tanggal : "-");
            holder.tvNama.setText(s.userName != null ? s.userName : "-");
            holder.tvShift.setText(s.shiftNama != null ? s.shiftNama : "-");
            String status = s.status != null ? s.status : "terjadwal";
            holder.tvStatus.setText(status);
        }

        @Override
        public int getItemCount() {
            return schedules.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTanggal, tvNama, tvShift, tvStatus;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvTanggal = itemView.findViewById(R.id.tvTanggal);
                tvNama = itemView.findViewById(R.id.tvNama);
                tvShift = itemView.findViewById(R.id.tvShift);
                tvStatus = itemView.findViewById(R.id.tvStatus);
            }
        }
    }
}
