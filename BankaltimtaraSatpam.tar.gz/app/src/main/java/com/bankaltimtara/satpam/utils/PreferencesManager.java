package com.bankaltimtara.satpam.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.bankaltimtara.satpam.models.User;
import java.util.HashSet;
import java.util.Set;

public class PreferencesManager {
    private static final String PREFS_NAME = "BankaltimtaraPrefs";
    private SharedPreferences prefs;
    private static PreferencesManager instance;

    private PreferencesManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized PreferencesManager getInstance(Context ctx) {
        if (instance == null) instance = new PreferencesManager(ctx.getApplicationContext());
        return instance;
    }

    public void setToken(String token) { prefs.edit().putString("fcm_token", token).apply(); }
    public String getToken() { return prefs.getString("fcm_token", ""); }

    public void setUserId(String id) { prefs.edit().putString("user_id", id).apply(); }
    public String getUserId() { return prefs.getString("user_id", ""); }

    public void setUserRole(String role) { prefs.edit().putString("user_role", role).apply(); }
    public String getUserRole() { return prefs.getString("user_role", "satpam"); }

    public void setUserName(String name) { prefs.edit().putString("user_name", name).apply(); }
    public String getUserName() { return prefs.getString("user_name", ""); }

    public void setLoggedIn(boolean loggedIn) { prefs.edit().putBoolean("logged_in", loggedIn).apply(); }
    public boolean isLoggedIn() { return prefs.getBoolean("logged_in", false); }

    public void saveUser(User u) {
        prefs.edit()
            .putString("user_id", u.id)
            .putString("user_name", u.name)
            .putString("user_email", u.email)
            .putString("user_role", u.role)
            .putString("user_nip", u.nip != null ? u.nip : "")
            .putString("user_posisi", u.posisi != null ? u.posisi : "")
            .putBoolean("logged_in", true)
            .apply();
    }

    public User getUser() {
        User u = new User();
        u.id = getUserId(); u.name = getUserName();
        u.email = prefs.getString("user_email", "");
        u.role = getUserRole(); u.nip = prefs.getString("user_nip", "");
        u.posisi = prefs.getString("user_posisi", "");
        return u;
    }

    public void logout() { prefs.edit().clear().apply(); }

    public Set<String> getNotifiedIds() {
        return prefs.getStringSet("notified_ids", new HashSet<>());
    }
    public void addNotifiedId(String id) {
        Set<String> set = new HashSet<>(getNotifiedIds());
        set.add(id);
        prefs.edit().putStringSet("notified_ids", set).apply();
    }
}
