package com.bankaltimtara.satpam.models;

import java.util.HashMap;
import java.util.Map;

public class Overtime {
    public String id, userId, userName, tanggal, shift, alasan, status;
    public double durasiJam; // total jam lembur
    public double tarifLembur; // per jam
    public double totalBayaran;
    public long approvedAt, createdAt;

    public static final String STATUS_PENDING = "pending";
    public static final String STATUS_DISETUJUI = "disetujui";
    public static final String STATUS_DITOLAK = "ditolak";

    public Overtime() {}

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("userId", userId); m.put("userName", userName);
        m.put("tanggal", tanggal); m.put("shift", shift);
        m.put("alasan", alasan); m.put("status", status != null ? status : STATUS_PENDING);
        m.put("durasiJam", durasiJam); m.put("tarifLembur", tarifLembur);
        m.put("totalBayaran", durasiJam * tarifLembur);
        m.put("approvedAt", approvedAt);
        m.put("createdAt", createdAt != 0 ? createdAt : System.currentTimeMillis());
        return m;
    }

    public static Overtime fromMap(String id, Map<String, Object> m) {
        Overtime o = new Overtime();
        o.id = id; o.userId = (String) m.get("userId"); o.userName = (String) m.get("userName");
        o.tanggal = (String) m.get("tanggal"); o.shift = (String) m.get("shift");
        o.alasan = (String) m.get("alasan"); o.status = (String) m.get("status");
        o.durasiJam = getDouble(m, "durasiJam");
        o.tarifLembur = getDouble(m, "tarifLembur");
        o.totalBayaran = getDouble(m, "totalBayaran");
        if (m.containsKey("approvedAt")) o.approvedAt = (Long) m.get("approvedAt");
        if (m.containsKey("createdAt")) o.createdAt = (Long) m.get("createdAt");
        return o;
    }

    private static double getDouble(Map<String, Object> m, String key) {
        Object v = m.get(key);
        if (v instanceof Double) return (Double) v;
        if (v instanceof Long) return ((Long) v).doubleValue();
        return 0;
    }
}
