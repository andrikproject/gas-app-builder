package com.bankaltimtara.satpam.admin;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankaltimtara.satpam.R;
import com.bankaltimtara.satpam.models.Attendance;
import com.bankaltimtara.satpam.models.Overtime;
import com.bankaltimtara.satpam.models.Schedule;
import com.bankaltimtara.satpam.models.User;
import com.bankaltimtara.satpam.services.FirebaseService;
import com.bankaltimtara.satpam.utils.DateUtils;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class AdminReportActivity extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView tvEmpty, tvTotalSatpam, tvTotalJadwal, tvTotalHadir, tvTotalLembur;
    private Spinner spinnerBulan, spinnerTahun;
    private Button btnFilter;

    private FirebaseService firebaseService;

    private List<User> allUsers;
    private List<Schedule> allSchedules;
    private List<Attendance> allAttendance;
    private List<Overtime> allOvertime;
    private ReportAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_report);

        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Laporan");
        }

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTotalSatpam = findViewById(R.id.tvTotalSatpam);
        tvTotalJadwal = findViewById(R.id.tvTotalJadwal);
        tvTotalHadir = findViewById(R.id.tvTotalHadir);
        tvTotalLembur = findViewById(R.id.tvTotalLembur);
        spinnerBulan = findViewById(R.id.spinnerBulan);
        spinnerTahun = findViewById(R.id.spinnerTahun);
        btnFilter = findViewById(R.id.btnFilter);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseService = FirebaseService.getInstance(this);

        setupSpinners();
        loadAllData();

        btnFilter.setOnClickListener(v -> applyFilter());
    }

    private void setupSpinners() {
        String[] bulan = {"Januari", "Februari", "Maret", "April", "Mei", "Juni",
                "Juli", "Agustus", "September", "Oktober", "November", "Desember"};
        ArrayAdapter<String> bulanAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, bulan);
        spinnerBulan.setAdapter(bulanAdapter);

        java.util.Calendar cal = java.util.Calendar.getInstance();
        int year = cal.get(java.util.Calendar.YEAR);
        String[] tahun = {String.valueOf(year - 1), String.valueOf(year), String.valueOf(year + 1)};
        ArrayAdapter<String> tahunAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, tahun);
        spinnerTahun.setAdapter(tahunAdapter);
        spinnerTahun.setSelection(1);
        spinnerBulan.setSelection(cal.get(java.util.Calendar.MONTH));
    }

    private void loadAllData() {
        showLoading(true);

        firebaseService.getUsers(new FirebaseService.FirebaseCallback<List<User>>() {
            @Override
            public void onSuccess(List<User> users) {
                allUsers = users;
                checkDataLoaded();
            }

            @Override
            public void onError(String errorMessage) {
                allUsers = new ArrayList<>();
                checkDataLoaded();
            }
        });

        firebaseService.getSchedules(new FirebaseService.FirebaseCallback<List<Schedule>>() {
            @Override
            public void onSuccess(List<Schedule> schedules) {
                allSchedules = schedules;
                checkDataLoaded();
            }

            @Override
            public void onError(String errorMessage) {
                allSchedules = new ArrayList<>();
                checkDataLoaded();
            }
        });

        firebaseService.getAttendance(new FirebaseService.FirebaseCallback<List<Attendance>>() {
            @Override
            public void onSuccess(List<Attendance> attendance) {
                allAttendance = attendance;
                checkDataLoaded();
            }

            @Override
            public void onError(String errorMessage) {
                allAttendance = new ArrayList<>();
                checkDataLoaded();
            }
        });

        firebaseService.getOvertime(new FirebaseService.FirebaseCallback<List<Overtime>>() {
            @Override
            public void onSuccess(List<Overtime> overtime) {
                allOvertime = overtime;
                checkDataLoaded();
            }

            @Override
            public void onError(String errorMessage) {
                allOvertime = new ArrayList<>();
                checkDataLoaded();
            }
        });
    }

    private int dataLoadCount = 0;

    private void checkDataLoaded() {
        dataLoadCount++;
        if (dataLoadCount >= 4) {
            runOnUiThread(() -> {
                dataLoadCount = 0;
                applyFilter();
            });
        }
    }

    private void applyFilter() {
        int bulanIndex = spinnerBulan.getSelectedItemPosition() + 1;
        String tahun = spinnerTahun.getSelectedItem().toString();
        String prefix = tahun + "-" + String.format("%02d", bulanIndex);

        // Filter data berdasarkan bulan
        List<ReportItem> reportItems = new ArrayList<>();

        int totalSatpam = 0;
        if (allUsers != null) {
            for (User u : allUsers) {
                if ("satpam".equalsIgnoreCase(u.role) && u.aktif) {
                    totalSatpam++;
                }
            }
        }

        int totalJadwal = 0;
        if (allSchedules != null) {
            for (Schedule s : allSchedules) {
                if (s.tanggal != null && s.tanggal.startsWith(prefix)) {
                    totalJadwal++;
                }
            }
        }

        int totalHadir = 0;
        int totalTerlambat = 0;
        if (allAttendance != null) {
            for (Attendance a : allAttendance) {
                if (a.tanggal != null && a.tanggal.startsWith(prefix)) {
                    String st = a.status != null ? a.status : "";
                    switch (st) {
                        case "hadir": totalHadir++; break;
                        case "terlambat": totalTerlambat++; break;
                    }
                    reportItems.add(new ReportItem(
                            a.userName != null ? a.userName : "-",
                            a.tanggal, a.status != null ? a.status : "-",
                            "Absensi"));
                }
            }
        }

        double totalJamLembur = 0;
        if (allOvertime != null) {
            for (Overtime o : allOvertime) {
                if (o.tanggal != null && o.tanggal.startsWith(prefix)
                        && "disetujui".equals(o.status)) {
                    totalJamLembur += o.durasiJam;
                    reportItems.add(new ReportItem(
                            o.userName != null ? o.userName : "-",
                            o.tanggal, "Lembur " + String.format("%.1f jam", o.durasiJam),
                            "Lembur"));
                }
            }
        }

        tvTotalSatpam.setText(String.valueOf(totalSatpam));
        tvTotalJadwal.setText(String.valueOf(totalJadwal));
        tvTotalHadir.setText(String.valueOf(totalHadir));
        tvTotalLembur.setText(String.format(Locale.getDefault(), "%.1f jam", totalJamLembur));

        // Tampilkan di recycler
        if (reportItems.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Tidak ada data untuk periode ini");
        } else {
            Collections.sort(reportItems, (a, b) -> b.tanggal.compareTo(a.tanggal));
            adapter = new ReportAdapter(reportItems);
            recyclerView.setAdapter(adapter);
            recyclerView.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
        }

        showLoading(false);
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        btnFilter.setEnabled(!show);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    static class ReportItem {
        String nama, tanggal, keterangan, tipe;
        ReportItem(String nama, String tanggal, String keterangan, String tipe) {
            this.nama = nama;
            this.tanggal = tanggal;
            this.keterangan = keterangan;
            this.tipe = tipe;
        }
    }

    static class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ViewHolder> {
        private final List<ReportItem> items;

        ReportAdapter(List<ReportItem> items) {
            this.items = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_report_admin, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            ReportItem item = items.get(position);
            holder.tvNama.setText(item.nama);
            holder.tvTanggal.setText(item.tanggal);
            holder.tvKeterangan.setText(item.keterangan);
            holder.tvTipe.setText(item.tipe);
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvNama, tvTanggal, tvKeterangan, tvTipe;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvNama = itemView.findViewById(R.id.tvNamaUser);
                tvTanggal = itemView.findViewById(R.id.tvTanggal);
                tvKeterangan = itemView.findViewById(R.id.tvKeterangan);
                tvTipe = itemView.findViewById(R.id.tvTipe);
            }
        }
    }
}
